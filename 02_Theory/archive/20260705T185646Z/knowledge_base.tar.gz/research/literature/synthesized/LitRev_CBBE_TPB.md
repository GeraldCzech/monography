# Synthesized Knowledge Unit (SKU): CBBE as a Latent Construct within the Theory of Planned Behavior

---

## Topic

This SKU addresses the integration of Customer-Based Brand Equity (CBBE) as a basic latent construct within Theory of Planned Behavior (TPB) frameworks. It synthesises evidence from 50 empirical and review studies spanning 2016–2026, covering commercial consumer markets (automotive, insurance, food, tourism, higher education). Its primary purpose within the BEBA Research Platform is to establish the theoretical and empirical basis for positioning CBBE—and its constituent dimensions—within BEBA's Brand Equity Layer and its causal connections to the Behavioural Layer.

---

## Scientific Relevance

CBBE and TPB are independently among the most cited frameworks in consumer behaviour research. Their integration addresses a recognised gap: TPB's attitude construct captures affective and evaluative orientations toward a behaviour but does not specify what shapes those orientations. CBBE supplies a structured account of the brand-related cognitive and affective content that determines attitude formation. Integrating CBBE into TPB therefore improves both theoretical completeness and empirical predictive validity (Wu et al., 2020). For BEBA, this integration is directly relevant because nonprofit donors must form attitudes toward the act of giving to a specific organisation—attitudes that are demonstrably shaped by brand perceptions.

---

## Historical Development

TPB (Ajzen, 1985; applied to food consumption in Ajzen, 2016) and CBBE (Aaker, 1991; Keller, 1993—neither directly cited in the source review but implied by all definitions used) developed independently in the 1990s. Early integration attempts appear in the literature around 2017 (Jiang et al., 2017; Liu et al., 2017), with more systematic integration following from 2018 (Abdullah et al., 2018) and consolidation through a meta-analysis in 2020 (Wu et al., 2020). Sector-specific applications proliferated after 2020 (Zheng et al., 2025; Rizwan et al., 2021; Louvet, 2023; Ruangkanjanases et al., 2022), extending the integrated framework to EVs, insurance, sports nutrition, and digital marketing contexts. Green and sustainable brand equity variants emerged by 2025 (Hue & Huyen, 2025). The trajectory indicates a maturing integration literature, though still without standardised operationalisation across sectors.

---

## Major Theoretical Schools

**1. Dimensional CBBE (Aaker tradition):** CBBE as four components—awareness, associations (including image and personality), perceived quality, and loyalty. This is the implicit framework in Wu et al. (2020) and most included empirical studies. The components are treated as reflective indicators of an underlying CBBE factor or as formative causes, depending on the study.

**2. Knowledge-based CBBE (Keller tradition):** CBBE rooted in consumer brand knowledge (brand awareness + brand image as associations), emphasised in luxury and service contexts (Liu et al., 2017). Partially overlaps with Aaker.

**3. Integrated latent-variable framing:** Wu et al. (2020) treats CBBE as a higher-order latent construct encompassing all dimensions; CBBE then functions as a structural antecedent to TPB constructs. This is the most relevant framing for BEBA modelling.

**4. Mediation/process framing:** Some studies position brand equity not as an upstream exogenous variable but as a mediating mechanism through which upstream inputs (social media, novelty, engagement) operate on downstream intentions (Ruangkanjanases et al., 2022; Zhang et al., 2020; Goyal & Verma, 2021). These studies imply that CBBE is itself endogenous to communication and experience processes.

**5. TPB extensions and IBM:** Rozenkowska (2023) and Ulker-Demirel & Ciftci (2020) review TPB applications systematically but do not integrate CBBE explicitly. Their work contextualises where CBBE integration fits within the broader TPB extension literature (including Integrated Behavioral Model, IBM).

---

## Canonical Definitions

**Customer-Based Brand Equity (CBBE):** The differential effect of brand knowledge on consumer response to a brand's marketing. Operationalised in the reviewed literature through four dimensions: brand awareness, brand associations (including image and personality), perceived quality, and brand loyalty. Brand trust is additionally included as a CBBE element in Wu et al. (2020).

**Brand attitude:** The consumer's overall evaluative response to the brand, functioning as a mediator between CBBE components and behavioural intention within TPB. This is distinct from TPB's "attitude toward the behaviour," though the two are often conflated or conflated by design in integrated models.

**Behavioural intention (TPB):** The motivational antecedent to behaviour, determined by attitude, subjective norms, and PBC. In integrated CBBE–TPB models, CBBE dimensions influence intention via attitude and sometimes directly.

**Perceived behavioural control (PBC):** Consumer's perceived ease or difficulty of performing the behaviour. In CBBE–TPB models, brand equity elements (particularly awareness and quality) are found to influence PBC (Wu et al., 2020; Zheng et al., 2025).

---

## Core Mechanisms

**Antecedents → CBBE:**
- Social media marketing activities (Ruangkanjanases et al., 2022)
- Brand engagement (Goyal & Verma, 2021)
- Novelty/product experience (Zhang et al., 2020)
- Authenticity perceptions (Phung et al., 2019)
- Green/sustainability cues (Hue & Huyen, 2025)

**CBBE dimensions → TPB constructs (direct paths):**
- Brand image, personality, associations → brand attitude (Wu et al., 2020; Zheng et al., 2025; Liu et al., 2017)
- Brand awareness, quality, trust → loyalty and PBC (Wu et al., 2020)
- CBBE aggregate → subjective norm pathway: contested; Wu et al. (2020) treats subjective norm as an antecedent of attitude, creating a parallel rather than sequential model

**Mediators between CBBE and intention:**
- Brand attitude (Zheng et al., 2025; Liu et al., 2017): strongest and most consistent mediator
- Customer satisfaction (Rambocas et al., 2017): partial mediation; also links to WOM and WTP
- Motivation (Jiang et al., 2017): in tourism contexts

**Moderators:**
- Price perception (Zheng et al., 2025): high perceived price weakens CBBE → intention paths
- Demographic factors (Zheng et al., 2025; Rizwan et al., 2021): age, income, and other characteristics reported as moderators; precise effects not detailed in source text

**Outcomes:**
- Purchase/donation intention (primary outcome across all studies)
- Attitudinal loyalty, behavioural loyalty (Goyal & Verma, 2021)
- WOM and brand switching (Rambocas et al., 2017; Saeed & Azmi, 2019)
- Engagement behaviour (Ruangkanjanases et al., 2022)
- Willingness to pay premium (Abdullah et al., 2018)

---

## Empirical Evidence

The empirical base is broad in sector coverage but narrow in context type: all 50 included primary studies are from commercial consumer markets. The meta-analysis (Wu et al., 2020, aggregating 173 studies) provides the strongest quantitative synthesis. Key robust findings are:

1. CBBE → behavioural intention: consistently positive, statistically significant, across all sectors studied. Effect sizes are not reported with precision in the source review text.
2. CBBE+TPB > TPB alone or CBBE alone in model fit: demonstrated explicitly in Wu et al. (2020) and Zheng et al. (2025).
3. Brand attitude mediates CBBE → intention: replicated across luxury hotels (Liu et al., 2017), EVs (Zheng et al., 2025), and implicitly in the meta-analytic structure (Wu et al., 2020).
4. Satisfaction as additional mediator: confirmed by Rambocas et al. (2017) in banking; limited replication.
5. Dimension-specific effects vary by context: awareness less important for EVs; all three dimensions significant for insurance. Cross-sector standardisation unresolved.

No longitudinal evidence, no experimental evidence, no nonprofit evidence is present in the included literature.

---

## Theoretical Tensions

**1. Is brand attitude the same as TPB attitude?**
The standard TPB "attitude toward the behaviour" (e.g., "I think donating to X is a good thing to do") differs conceptually from "attitude toward the brand" (e.g., "I think well of this organisation"). Integrated CBBE–TPB models frequently conflate or merge these, which threatens construct validity. The source review does not address this tension explicitly.

**2. Is CBBE a latent cause, a reflective factor, or a formative composite?**
The reviewed literature treats CBBE inconsistently: as a higher-order reflective factor (Wu et al., 2020), as a formative composite of four dimensions (Aaker tradition), or as an outcome construct that is itself mediated (Ruangkanjanases et al., 2022). These are not equivalent measurement models and yield different causal inference structures. This tension is the most consequential unresolved issue for BEBA model specification.

**3. Structural placement of subjective norms:**
Wu et al. (2020) models subjective norms as antecedents of brand attitude (i.e., upstream of the attitude construct), which contradicts the standard TPB structure where subjective norms and attitude are parallel predictors of intention. This structural choice significantly alters the meaning and role of social influence.

**4. Direction of loyalty:**
Brand loyalty appears both as a CBBE component (reflecting the strength of existing equity) and as an outcome of the CBBE–TPB process. Treating it as both input and output creates circularity that most included studies do not address.

---

## Boundary Conditions

1. **Commercial exchange context:** All evidence comes from voluntary commercial purchases where consumers receive direct material benefits. Charitable giving involves no direct material exchange, changes the motivational structure, and may alter which CBBE dimensions are most operative.
2. **Positive brand equity:** The entire literature base examines brands with established or positive equity. Effects of weak, negative, or unknown brand equity are not studied.
3. **Product involvement:** High-involvement purchases (EVs) show different CBBE dimension salience compared to low-involvement or habitual purchases. Donation behaviour varies in involvement by donor segment.
4. **Measurement standardisation:** No cross-sector validated CBBE scale within the TPB integration framework exists; comparability across included studies is limited.
5. **Single-context, cross-sectional design:** All primary studies are cross-sectional; causal claims about CBBE shaping attitude and intention are theoretically motivated but not longitudinally confirmed.

---

## Criticism

1. **Publication bias:** The evidence map reveals no null or negative findings. The source review does not assess publication bias explicitly. This creates an artificially positive picture of the CBBE–TPB integration.
2. **Conceptual conflation:** Several integrated models blur brand attitude and behavioural attitude, weakening theoretical precision (see Tensions above).
3. **Sector parochialism:** The literature has developed in isolated sector silos (automotive, insurance, tourism) with limited cross-sector validation of structural paths or scale equivalence.
4. **Generalisability to nonprofit:** None of the 50 included studies involve charities, nonprofits, public goods, or altruistic behaviour. The transfer of commercial CBBE–TPB findings to BEBA requires explicit theoretical bridging arguments, not assumption.
5. **Mediator proliferation:** The literature proposes multiple mediators (attitude, satisfaction, motivation, engagement) without a principled account of when each operates. This risks capitalisation on chance in sector-specific models.

---

## Connections to BEBA

**Layer placement:**
- CBBE as a higher-order latent construct belongs primarily in BEBA's **Brand Equity Layer (Layer 4)**, spanning its dimensions: brand awareness/familiarity, brand image, brand personality, brand trust, brand commitment, brand credibility, brand authenticity, and brand reputation.
- CBBE's influence on TPB constructs operates across the boundary between Layer 4 (Brand Equity) and **Layer 5 (Behavioural Layer)**, where attitude, subjective norms, PBC, and behavioural intention reside.
- The antecedents of CBBE found in the reviewed literature (social media, experience, authenticity perceptions) map to BEBA's **Information Economics Layer (Layer 2)** (signalling) and **Institutional Layer (Layer 3)** (legitimacy, reputation formation).

**Causal connections to BEBA model:**
- The core CBBE → attitude → intention pathway from the reviewed literature maps directly onto the Brand Equity Layer → Behavioural Layer → Resource Layer sequence in BEBA.
- Brand trust (identified as both CBBE component and mediator in Wu et al., 2020) corresponds to BEBA's BO_TR (Boenigk & Becker brand trust). The finding that brand trust predicts loyalty supports BO_TR → BO_CO (commitment) path.
- Brand image and personality (CBBE components that predict attitude) correspond to BEBA's FC_BI and FC_BP (Faircloth model).
- Authenticity perceptions as antecedents of CBBE (Phung et al., 2019) connect to BEBA's RO_BW (Romero authenticity) and, through it, to brand equity and donation intention (RO_ID).
- Satisfaction as mediator (Rambocas et al., 2017) does not have a direct BEBA analogue and may represent a construct to assess for future inclusion.

**Caution for nonprofit application:** The motivational structure of charitable giving differs fundamentally from commercial purchase. In BEBA's context, subjective norms (Layer 5) may carry greater weight relative to PBC than in commercial contexts, because giving is prosocial and identity-signalling. CBBE dimensions related to reputation and trustworthiness (FC_BI, BO_TR, RO_BR) may be more decisive than awareness or perceived quality in driving donation intention. These hypotheses require nonprofit-specific empirical testing.

---

## Connections to Existing BEBA Models

**Faircloth model (FC_BI, FC_BP, FC_BF):**
- The reviewed literature strongly supports treating FC_BI (brand image) and FC_BP (brand personality) as CBBE components that function as antecedents of brand attitude (Wu et al., 2020; Liu et al., 2017). This validates Faircloth's positioning of image and personality as upstream equity drivers.
- FC_BF (brand familiarity) maps onto brand awareness (CBBE component). The finding that awareness is less critical in high-involvement contexts (Zheng et al., 2025) suggests FC_BF may be less decisive for major donors or for repeat/habitual donors in BEBA, while remaining important for new-donor acquisition.

**Boenigk & Becker model (BO_TR, BO_CO):**
- BO_TR (brand trust) appears explicitly as a CBBE component in Wu et al. (2020), predicting loyalty. This is consistent with BO_TR's central role in the Boenigk & Becker framework.
- BO_CO (brand commitment) corresponds to brand loyalty as an outcome of CBBE. The Goyal & Verma (2021) finding that brand engagement predicts attitudinal loyalty and brand equity supports the bidirectionality between trust, commitment, and equity.

**Romero et al. model (RO_BW, RO_BR, RO_ID):**
- RO_BW (brand authenticity/worthiness) is supported as an antecedent of CBBE by Phung et al. (2019), which found that authenticity perceptions increase brand equity and brand choice intention.
- RO_BR (brand reputation) overlaps with brand image and associations (CBBE components); the reviewed literature supports reputation as an upstream equity driver rather than a separate outcome variable.
- RO_ID (donation intention) is the charitable-giving analogue of the purchase intentions studied throughout this literature; the CBBE → attitude → intention path provides the structural template.

**TPB:**
- The entire review directly validates the relevance of the TPB structure. However, the structural placement of CBBE relative to TPB constructs is not yet standardised. The most defensible integration for BEBA places CBBE dimensions as antecedents of TPB attitude and, to a lesser degree, PBC; not as replacements for TPB constructs.

**IBM (Integrated Behavioral Model):**
- The IBM extensions to TPB (knowledge, salience, habit, constraints) are not addressed by any included study. This represents a significant gap: BEBA's use of IBM to account for donor knowledge, issue salience, and habitual giving behaviour has no direct CBBE–IBM integration precedent in this literature.

---

## Implications for Model Competition

The reviewed literature suggests that brand attitude is the most consistent and robust mediator between CBBE and intention. This implies that in BEBA model comparisons, a model that includes an explicit brand attitude mediator between the Brand Equity Layer and behavioural intention will outperform models that connect brand equity directly to intention without mediation. However, the brand attitude construct must be clearly distinguished from TPB's "attitude toward donating," as conflation reduces theoretical parsimony. A clean BEBA model would specify: CBBE dimensions → brand attitude (affective/evaluative response to the organisation) → attitude toward donating → intention → donation behaviour.

The finding that integrated CBBE+TPB models consistently outperform single-framework models supports BEBA's multi-layer design. Models that collapse the Brand Equity and Behavioural layers, or that omit brand equity constructs, will be theoretically under-specified and likely show inferior fit.

---

## Open Research Questions

1. **Which CBBE dimensions are most predictive of donation intention in nonprofit contexts?** The commercial literature suggests this varies by product involvement; nonprofit contexts require independent testing.
2. **Does brand attitude mediate CBBE → donation intention in the same way it mediates CBBE → purchase intention?** The commercial mediation chain is robust; charitable giving may involve different attitudinal structures (moral evaluation, identity congruence) that alter or supplement the standard mediation path.
3. **How does nonprofit brand equity interact with TPB's subjective norms construct?** Charitable giving is strongly normative and identity-driven; the reviewed literature provides no guidance on norm–equity interactions in prosocial contexts.
4. **Can CBBE be operationalised as a higher-order latent variable in BEBA's SEM?** Wu et al. (2020) suggests yes; but the dimensionality of nonprofit brand equity (which includes authenticity, credibility, and legitimacy dimensions absent from commercial CBBE frameworks) may require model adaptation.
5. **What is the role of habit and constraints (IBM constructs) in moderating or suppressing CBBE → intention paths?** The intersection of IBM and CBBE is entirely unaddressed.
6. **Does negative or absent brand equity (low awareness, poor image) suppress donation intention even when attitude and norms are positive?** Not sufficiently covered in the reviewed literature; directly relevant for BEBA's work on small or less-known Austrian nonprofits.

---

## Suggested Ontology Entries

The following concepts from this review warrant formal ontology entries in BEBA's construct ledger (see Step 3 for detailed specifications):

1. **CBBE (Customer-Based Brand Equity)** — as a higher-order latent construct in the Brand Equity Layer
2. **Brand Attitude** — as a mediating construct at the boundary of the Brand Equity and Behavioural Layers
3. **Brand Awareness / Familiarity** — as a CBBE sub-dimension and antecedent of attitude and PBC
4. **Perceived Quality** — as a CBBE sub-dimension relevant to credence goods / nonprofit service evaluation
5. **Satisfaction** — as a potential mediator requiring assessment for inclusion in BEBA

---

## Suggested Dissertation Use

1. **Chapter 2 (Literature Review):** Use the CBBE–TPB integration evidence to justify positioning brand equity constructs as antecedents of attitude and PBC within BEBA's Behavioural Layer. Cite Wu et al. (2020) as the primary meta-analytic foundation. Note explicitly that all evidence is from commercial contexts and that nonprofit application requires cautious bridging arguments.
2. **Chapter 3 (Theoretical Framework):** Use the integrated latent-variable framing (Wu et al., 2020) to formally specify CBBE as a higher-order construct in BEBA's SEM. Define the CBBE → brand attitude → donation intention path as the central theoretical mechanism, clearly distinguishing brand attitude from TPB's behavioural attitude.
3. **Chapter 5 (Discussion):** Use the boundary conditions (commercial vs. prosocial context; positive equity only; cross-sectional design) to motivate the original contribution of testing this integration in an Austrian nonprofit context.
4. **Do not use** the source review as evidence for nonprofit-specific effects; flag explicitly that generalisation from commercial to charitable-giving contexts is a theoretical assumption requiring empirical testing within BEBA.

---

## Confidence Assessment

| Dimension | Level | Justification |
|---|---|---|
| Conceptual clarity | **High** | CBBE dimensions and their relationship to TPB constructs are clearly specified in the reviewed literature; the higher-order latent construct framing (Wu et al., 2020) is sufficiently formal for SEM implementation |
| Empirical maturity | **Medium** | Strong meta-analytic foundation in commercial contexts; zero nonprofit evidence; no longitudinal studies; no negative-equity studies; cross-sector standardisation unresolved |
| Relevance for BEBA | **Medium** | The structural CBBE → attitude → intention mechanism is directly relevant; the specific commercial context of all evidence requires explicit bridging; the IBM-related extensions (salience, habit, constraints) are untouched by this literature |
