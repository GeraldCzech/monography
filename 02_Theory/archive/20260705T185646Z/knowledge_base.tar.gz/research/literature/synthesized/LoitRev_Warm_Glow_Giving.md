# Scientific Summary

Warm glow giving, defined as the private utility or emotional satisfaction a donor receives from the act of giving, is a significant and empirically robust motivator for charitable donations. The literature, originating with Andreoni's (1989, 1990) theory of "impure altruism," distinguishes warm glow from pure altruism (concern for the recipient's welfare). Experimental evidence, particularly from "crowd-out" designs, consistently shows that individuals donate even when their contribution has no marginal impact on the total funds received by the charity, providing direct support for warm glow motivations (Crumpler & Grossman, 2008). This effect is driven by both internal self-image maintenance ("I am a good person") and external social-image concerns ("others see me as generous"), with the former influencing the decision to give and the latter influencing the amount given (Grossman & Levy, 2024). The strength of the warm glow effect is moderated by contextual factors, including the source of income (earned vs. windfall), the framing of fundraising appeals, and the architecture of choice environments.

# Core Mechanisms

The central theoretical mechanisms driving warm glow giving are:

1.  **Private Utility from the Act of Giving:** The core mechanism is that the act of donating itself enters the donor's utility function. The donor derives satisfaction *from their contribution*, separate from the satisfaction derived from the public good's provision (Andreoni, 1990).

2.  **Self-Image Enhancement:** Donating reinforces a positive self-concept of being a generous, caring, or morally good person. This internal reward system motivates the initial act of giving (Grossman & Levy, 2024).

3.  **Social-Image Signalling:** Giving publicly, or in a way that is observable to others, signals prosocial traits. The desire for social prestige or approval from one's community increases the *amount* given by those who already decided to donate (Grossman & Levy, 2024; Harbaugh, 1998).

4.  **Affective Reward:** The "glow" is an emotional or affective response. Neuroeconomic studies confirm that donating can activate reward centres in the brain, similar to receiving a direct benefit, creating a tangible "feel-good" experience (Harbaugh et al., 2007).

# Consensus

The literature demonstrates strong consensus on several key points:

*   **Warm glow is a real and significant driver of donations:** There is strong and consistent experimental evidence that giving persists even under full crowd-out conditions (Crumpler & Grossman, 2008; Bianchi et al., 2023).
*   **Most donors are "impure altruists":** The dominant model of giving is one where donors are motivated by a combination of pure altruism and warm glow, not just one or the other (Andreoni, 1990; Wilhelm et al., 2014).
*   **Self-image and social-image have distinct effects:** Self-image concerns are primary drivers of participation (the decision to give), while social-image concerns tend to increase the magnitude of the donation (Grossman & Levy, 2024).
*   **Donating earned income generates a stronger warm glow:** Individuals derive more utility from giving money they have worked for compared to windfall gains (Luccasen & Grossman, 2017).
*   **Fundraising appeals can effectively leverage warm glow:** Messaging that emphasizes the donor's self-benefit ("feel good by giving") can outperform appeals focused solely on recipient benefits (List et al., 2021).

# Disagreement

The literature does not show major disagreements on the existence of warm glow, but rather on its scope and the completeness of the model. Areas of debate or nuance include:

*   **Sufficiency of the Model:** There is a debate about whether the standard impure altruism model is sufficient to explain all forms of charitable giving, particularly in contexts driven by strong religious or moral obligations where other-regarding preferences may be structured differently (Fraser, 2018; Fraser, 2022).
*   **The "Cooling" Effect:** While warm glow is a motivator, its effect is not monotonic or guaranteed. The conditions under which prosocial behaviour is "cooled" by factors like skepticism, perceived inauthenticity, or excessive publicity are an area of active investigation, not yet fully settled (Chaabouni et al., 2020).
*   **Relationship with Nudges:** There is some debate on whether external interventions like nudges enhance or potentially "crowd out" intrinsic warm glow motivations. Current evidence suggests they can be complementary, but the interaction is complex (Gråd et al., 2021).

# Boundary Conditions

The warm glow effect is not universal and its strength is moderated by several factors that act as boundary conditions:

*   **Source of Funds:** The effect is stronger for earned income than for windfall gains (Luccasen, & Grossman, 2017).
*   **Observability:** The social-image component of warm glow is only activated under conditions of observability, whereas the self-image component can operate in private (Grossman & Levy, 2024).
*   **Campaign Framing:** The effect can be enhanced or diminished by fundraising messages that appeal to either self-focused or other-focused benefits (List et al., 2021).
*   **Donation Size (in CRM):** In cause-related marketing, small donation sizes effectively generate warm glow, while large, highly publicized donations may trigger skepticism and reduce the effect (Chaabouni et al., 2020).
*   **Cultural/Religious Context:** The standard economic model of warm glow may be a less powerful predictor in communities with strong, pre-existing norms of giving based on faith or duty (Fraser, 2022).
*   **Choice Architecture:** The presence of an option to "take" from a charity can reduce, but does not eliminate, warm glow giving (Luccasen, & Grossman, 2017).

# Research Gaps

The reviewed literature identifies several clear research gaps:

*   **Cross-Cultural Variation:** The vast majority of research is conducted in Western, educated, industrialized, rich, and democratic (WEIRD) societies. How warm glow motivations manifest and are leveraged in different cultural contexts is largely unknown.
*   **Long-Term Dynamics ("Warmth Decay"):** The sustainability of warm glow as a motivator over time is not well understood. Research is needed on whether repeated exposure to warm glow appeals leads to diminishing returns or donor fatigue.
*   **Digital and Crowdfunding Platforms:** How modern digital fundraising environments (e.g., social media campaigns, crowdfunding platforms) mediate, enhance, or alter warm glow mechanisms is a significant gap.
*   **Integration with Other Frameworks:** There is a need for better integration of the economic warm glow model with moral, religious, and identity-based frameworks for giving.
*   **Conditions for Skepticism ("Cooling"):** More research is needed on the specific triggers that cause donors to become skeptical and "cool" the warm glow effect, particularly in response to nonprofit marketing and large-scale campaigns.

# BEBA Implications

The concept of warm glow giving has profound implications for the BEBA framework:

1.  **Warm Glow as a Core Behavioural Mechanism:** Warm glow is a primary psychological utility that a nonprofit brand's behaviour architecture can be designed to deliver. The "feel-good" effect is a direct, appetitive consequence of the desired behaviour (donating).

2.  **Brand as a Heuristic for Warm Glow:** Under conditions of uncertainty about a donation's ultimate impact, the brand can serve as a reliable heuristic that promises a high-quality warm glow experience. A trusted brand reduces the perceived risk that the act of giving will not produce the desired emotional reward.

3.  **Architecting for Self-Image and Social-Image:** BEBA can model how brands architect different touchpoints to trigger distinct warm glow mechanisms.
    *   *Private channels* (e.g., email appeals, website donation forms) can be architected to reinforce self-image ("You are a good person for doing this").
    *   *Public channels* (e.g., social media share buttons, donor recognition lists) can be architected to facilitate social-image signalling ("Show your friends you support this cause").

4.  **Decoupling Behaviour from Outcome:** The warm glow phenomenon is a perfect example of a mechanism that drives behaviour independent of the outcome for the beneficiary. This aligns with BEBA's principle of "Behaviour before brands," as it focuses on the donor's immediate behavioural reinforcement. For the donor, the behaviour *is* the reward.

5.  **Mapping to the BEBA Information Model:**
    *   **Concept:** Warm Glow Giving.
    *   **Theory:** Impure Altruism (Andreoni, 1990).
    *   **Constructs:** Self-Image Motivation, Social-Image Motivation, Affective Response to Giving.
    *   **Relationship:** Brand communications (as part of the BEBA) that frame giving as identity-affirming (Claim) will increase the salience of Self-Image Motivation (Construct), which in turn mediates the likelihood of donation (Behaviour).

# Candidate Claims

Based on the literature review, the following scientific claims can be formulated for testing within the BEBA framework:

*   **CLAIM-WG-01:** The act of donating provides private utility (warm glow) to the donor, distinct from the utility derived from the provision of the public good itself.
*   **CLAIM-WG-02:** Self-image concerns are a primary driver of an individual's initial decision to donate.
*   **CLAIM-WG-03:** Social-image concerns are a primary driver of the amount donated, conditional on the decision to give having been made.
*   **CLAIM-WG-04:** Donations made from earned income generate a stronger warm glow response and lead to higher contribution levels compared to donations made from windfall income.
*   **CLAIM-WG-05:** Fundraising appeals that emphasize the donor's emotional self-benefit (warm glow) are more effective at increasing donation rates and amounts than appeals focused solely on recipient benefits.
*   **CLAIM-WG-06:** In cause-related marketing contexts, the relationship between donation size and warm glow is non-linear, with large donation sizes potentially triggering skepticism that negates the positive effect.
*   **CLAIM-WG-07:** The predictive power of standard warm glow models diminishes in contexts governed by strong, pre-existing religious or moral frameworks for giving.