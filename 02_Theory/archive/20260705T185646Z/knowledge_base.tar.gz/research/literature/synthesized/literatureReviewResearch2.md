# Topic

**Synthesised Knowledge Unit: Networks/Hierarchical Models of Brand Equity; Brand Equity within TPB; Brand Equity within IBM — with application to charitable donation behaviour**

This SKU synthesises three interconnected sub-topics: (A) the hierarchical and network architecture of brand equity across for-profit and nonprofit sectors; (B) how brand equity dimensions feed into and shape the components of the Theory of Planned Behavior; and (C) how brand equity constructs map onto the Integrated Behavior Model, with specific attention to charitable donation contexts. Together they constitute the theoretical infrastructure through which the BEBA framework conceptualises the relationship between nonprofit brand equity and donor behaviour.

---

# Scientific Relevance

The three sub-topics address a central question in nonprofit marketing: by what cognitive, normative, and volitional mechanisms do brand perceptions translate into charitable actions? Sub-topic A establishes the structural architecture of brand equity — how awareness, image, quality, and loyalty are organised in hierarchical networks and which dimensions matter in nonprofit settings. Sub-topic B establishes the causal bridge: brand equity dimensions are antecedents of attitude, subjective norms, and perceived behavioural control — the proximal predictors of intention in TPB. Sub-topic C extends this bridge to IBM, which disaggregates TPB components further and adds direct behavioural determinants (knowledge, salience, constraints, habit), and provides substantial evidence that charitable donation intentions are robustly predicted by extended TPB/IBM-like structures even though formal IBM terminology is rarely used in the donation literature.

Collectively, this body of evidence justifies BEBA's theoretical position that nonprofit brand equity is not an end in itself but an upstream input into the motivational architecture that produces donation behaviour.

---

# Historical Development

**1993–2000:** Keller's CBBE model establishes awareness and image as the associative network foundations of brand equity; dimensions are defined, inter-related, and distinguished from firm-side financial equity. Aaker (not directly cited in this source, but implied by the systematic reviews) contributes a parallel dimensional model. These become the canonical frameworks.

**2000–2010:** The TPB (Ajzen) is applied to a widening range of health, environmental, and social behaviours. Early charitable donation studies (Smith & McSweeney, 2007) test extended TPB including moral norm and past behaviour, establishing moral norm as a robust predictor beyond standard TPB components.

**2010–2018:** SEM-based CBBE studies proliferate across retail, hotel, tourism, and smartphone sectors, validating hierarchical and multi-dimensional structures. The IBM (Fishbein & Yzer, 2003) is articulated as a more granular TPB variant, but its adoption in donation research remains limited. Employer branding and social behaviour gamification extend CBBE logic to new non-commercial domains (Theurer et al., 2018; Tanouri et al., 2019).

**2018–2023:** Integration studies explicitly combine CBBE and TPB (Wu et al., 2020 meta-analysis; Foroudi et al., 2018; Liu et al., 2017). The nonprofit domain develops its own brand equity framework (Romero et al., 2023). The meta-analysis by White et al. (2023) with 117 samples provides the strongest cumulative evidence for TPB in charitable giving. Nonprofit brand activism as a BE antecedent is investigated (Lee et al., 2023). Online donation and social media contexts bring new channel moderators (Obadă et al., 2024; Chen et al., 2019).

**2024–2025:** Reviews consolidate the field (Gutiérrez et al., 2023; Paschina, 2025). EV adoption provides a new cross-sectoral test of CBBE–TPB (Zheng et al., 2025). The gap of an explicit IBM–brand equity integration for charitable giving remains open.

---

# Major Theoretical Schools

**School 1: Cognitive/perceptual brand equity (Keller tradition)**
Brand equity is a consumer-side cognitive construction. Awareness and image (associations) form associative networks; hierarchical models cascade from awareness through image and quality to loyalty and resonance. Operationalisation is perceptual (survey-based SEM). This is the dominant framework in sub-topic A and the CBBE input to sub-topic B.

**School 2: Utility-based brand equity (Swait & Erdem)**
Brand equity is modelled as the information value of a brand that reduces consumer uncertainty and search costs in a utility-maximisation framework. Formally distinct from the perceptual tradition; connects to information economics rather than cognitive psychology. Less dominant in the reviewed literature but theoretically important for BEBA's Information Economics Layer.

**School 3: Planned behaviour theory tradition (TPB/IBM)**
Consumer decisions are driven by attitude (cognitive and affective evaluation of the behaviour), norms (social pressure), and perceived control (capability beliefs), channelled through intention. IBM extends this with experiential vs. instrumental attitude, injunctive vs. descriptive norms, self-efficacy, knowledge, salience, and habit. This tradition dominates donation research.

**School 4: Nonprofit brand equity (Romero et al., Lee et al.)**
Adapts CBBE logic to donor-facing brand management, substituting commercial loyalty with donor commitment, and emphasising authenticity, reputation, and differentiation alongside familiarity. Closely aligned with the BEBA framework's Brand Equity Layer.

**School 5: Moral–normative tradition in prosocial behaviour**
Extends TPB with moral norm (personal obligation) and past behaviour/habit. Consistently shows that moral norm and PBC dominate attitude in charitable giving. This school is less brand-centred but is essential context for any nonprofit BE model.

---

# Canonical Definitions

- **Customer-Based Brand Equity (CBBE):** The differential effect of brand knowledge (awareness + image) on consumer response (Keller, 1993).
- **Donor-Based Brand Equity:** Higher-order construct comprising familiarity, associations (authenticity, reputation, differentiation), and commitment, operationalised in NGO contexts (Romero et al., 2023).
- **Shared Brand Equity:** Brand equity arising from associations with another entity through collaboration (Cornwell et al., 2022).
- **Theory of Planned Behavior (TPB):** Attitude, subjective norms, and PBC → intention → behaviour (Ajzen; operationalised throughout sub-topic B and C sources).
- **Integrated Behavior Model (IBM):** Extended TPB with experiential/instrumental attitudes, injunctive/descriptive norms, perceived control/self-efficacy as intention determinants; knowledge, salience, environmental constraints, habit as direct behaviour determinants (Fishbein & Yzer, 2003, as cited in the source context).
- **Moral norm:** Personal sense of moral obligation, consistently the most powerful predictor of charitable donation intention beyond standard TPB (White et al., 2023).
- **Multidimensional trust:** Ability, integrity, and benevolence dimensions of organisational trust, functioning as brand credibility proxies in donation research (Lee & Kim, 2023).

---

# Core Mechanisms

## Antecedents → Mediators → Moderators → Outcomes

### For sub-topic A (Structural)
**Antecedents of brand equity:** Marketing programmes, brand communication, sponsorship/co-branding partners, brand activism, consumer touchpoints, social support (gamification).
**Mediators/Intermediate constructs:** Brand awareness/familiarity, brand associations/image, perceived quality/value, brand personality, brand trust.
**Outcomes:** Brand loyalty/commitment, word-of-mouth, purchasing, donation/volunteering, employee retention (employer branding), overall brand equity.
**Moderators:** Sector/context (retail, tourism, NGO, social behaviour), donor moral foundations (for brand activism), cultural setting.

### For sub-topic B (TPB mechanism)
**Antecedents (BE inputs):** Brand awareness, brand image/associations, brand personality, perceived quality, brand loyalty, brand trust, brand love.
**Mediators:** Brand attitude (primary mediator between BE dimensions and intention); subjective norm (social component connecting brand social meaning to normative pressure); PBC (capability component connecting brand familiarity/trust to ease of action).
**Moderators:** Perceived price (Zheng et al.), brand equity level (Foroudi et al.), cultural/product context.
**Outcomes:** Behavioural intention → actual behaviour (purchase, donation, adoption).

### For sub-topic C (IBM/donation mechanism)
**Antecedents:** Brand image, reputation, credibility/trust, organisational identification, past donation behaviour, religiosity, income, social norms in communication.
**Mediators:** Experiential and instrumental attitudes toward donating, injunctive and descriptive norms, perceived control/self-efficacy, donation intention.
**Direct behaviour determinants (IBM):** Salience of behaviour, habit/past behaviour, knowledge (not always significant), environmental constraints (not always significant).
**Moderators:** CEO reputation, message involvement, channel (online vs. offline), cultural/religious context, similarity to reference donors.
**Outcomes:** Donation intention, actual donation (money, time, blood, organs), donation amount, repeated giving.

---

# Empirical Evidence

## Sub-topic A
Evidence is predominantly cross-sectional SEM from commercial contexts (retail, tourism, smartphones). Hierarchical structures are consistently confirmed. The nonprofit-specific study (Romero et al., 2023) is a single primary study and requires replication. Systematic reviews (Gutiérrez et al., 2023; Paschina, 2025) confirm dimensional robustness across sectors but note the scarcity of nonprofit applications. Brand activism effects on nonprofit BE (Lee et al., 2023) are a single study with a specific moderator (moral foundations) that has not been replicated.

## Sub-topic B
A meta-analysis (Wu et al., 2020) provides the strongest evidence that CBBE dimensions predict brand attitude, which predicts intention within a TPB framework. Primary studies across EVs, hotels, smartphones, and tourism replicate this across diverse commercial contexts. The moderating role of brand equity on PBC→intention (Foroudi et al., 2018) is a single-study finding. All sub-topic B evidence is from commercial, not nonprofit, contexts.

## Sub-topic C
The White et al. (2023) meta-analysis (117 samples, 104 studies) provides the strongest and most comprehensive evidence base in this review: TPB and extended TPB robustly predict charitable donation intentions and, more modestly, behaviour. Moral norm is a particularly strong and consistent predictor. The brand equity variables (trust, reputation, image, organisational attitude) have been embedded into primary TPB-donation studies (Lee & Kim, 2023; Kim & Han, 2020; Obadă et al., 2024; Mittelman & Rojas-Méndez, 2018) with partial but not uniform support. No meta-analysis combines brand equity with donation TPB. The IBM is not formally labelled in any donation study; the evidence for IBM-specific constructs (as opposed to TPB) comes from green purchase research (Surucu et al., 2019; Siddique et al., 2020).

---

# Theoretical Tensions

**Tension 1: Moral norm versus brand/organisational attitude**
In charitable donation contexts, moral norm and PBC consistently dominate attitude toward the organisation as predictors of intention. Mittelman & Rojas-Méndez (2018) find attitude toward the charitable organisation non-significant. This challenges BEBA's assumption that brand equity (manifested partly as organisational attitude) is a strong proximal driver of donation intention. The resolution may be that brand equity operates more distally — shaping the ethical salience and perceived competence of the cause — rather than generating direct attitudinal valence toward donating.

**Tension 2: Brand equity as antecedent vs. moderator of TPB paths**
The literature uses brand equity both as an antecedent of TPB components (especially attitude) and as a moderator of the PBC→intention path (Foroudi et al., 2018). These are conceptually distinct causal roles, and the conditions under which each applies are not theoretically resolved.

**Tension 3: Cognitive/perceptual CBBE vs. utility-based models**
Keller's associative network tradition operationalises brand equity as perceived dimensions measured by survey scales, while Swait & Erdem's utility-based approach models brand equity as formal information value. The two are not easily reconciled, and the choice of paradigm has implications for model testability and measurement in BEBA.

**Tension 4: IBM specificity vs. extended TPB convergence**
The IBM was designed to provide greater precision than TPB (separating experiential from instrumental attitudes, injunctive from descriptive norms, self-efficacy from PBC). However, the donation literature has converged on "IBM-like" extended TPB structures without adopting IBM terminology. This creates a terminological gap: the constructs are largely compatible but the theoretical identity of models in the literature is inconsistent.

**Tension 5: Social norms — brand community or generic social pressure?**
In commercial contexts, brand-related social meaning (brand love, social image) feeds into subjective norms. In donation contexts, religiosity-based norms and peer giving norms are dominant. Whether nonprofit brand equity can meaningfully shape subjective norms around charitable giving (as it does in commercial purchase contexts) is unresolved.

---

# Boundary Conditions

- The BE→attitude→intention chain is well-established for commercial for-profit contexts; its direct applicability to nonprofit/charitable contexts requires qualification given the dominance of moral norm in that literature.
- Hierarchical BE structures are context-specific; the Romero et al. NGO model should not be assumed to generalise without replication in Austrian/German-speaking nonprofit sectors.
- CEO and organisational reputation effects on donation intention are highly condition-dependent (Kim & Han, 2020): reputational damage qualitatively restructures the intention model.
- Cultural, religious, and economic contexts moderate norm strength and attitude–intention relationships; Austrian-specific calibration is required.
- Online channel effects on donation determinants differ from offline; channel is a structural moderator for BEBA's Resource Layer.
- IBM's direct behaviour determinants (knowledge, salience, constraints, habit) have not been empirically mapped to brand equity in donation contexts; their boundary conditions remain unknown in this setting.

---

# Criticism

- The CBBE literature is dominated by cross-sectional SEM, which cannot establish causal priority between brand dimensions or test dynamic accumulation of brand equity over time.
- Sub-topic B studies are almost exclusively from commercial sectors; the inference that BE–TPB mechanisms transfer to charitable giving is logically plausible but empirically unconfirmed.
- No study in the reviewed set explicitly operationalises or tests the full IBM for charitable giving; calling donation TPB models "IBM-like" is an interpretation, not a documented finding.
- The Romero et al. (2023) NGO brand equity model is a single study without cross-cultural replication; it is the closest model to BEBA's nonprofit context but cannot be treated as settled evidence.
- Wu et al. (2020) is a meta-analysis but it pooled heterogeneous commercial contexts; its generalisability to nonprofit donation behaviour is limited.
- Several source citations have incomplete journal details (Swait & Erdem, 2023 lacks full citation); this reduces verifiability.
- The Consensus AI search tool used to generate the source may have introduced selection biases; the evidence map reflects what was indexed rather than a fully systematic protocol.

---

# Connections to BEBA (Layer Placement and Causal Links)

## Sub-topic A connects to:
- **Brand Equity Layer (Layer 4):** Directly defines the architecture of BEBA's Brand Equity Layer. The reviewed models confirm that awareness/familiarity (FC_BF), brand image (FC_BI), brand personality (FC_BP), brand trust (BO_TR), brand commitment (BO_CO), authenticity (RO_BW), and reputation (RO_BR) are appropriate dimensions. Hierarchical models suggest these dimensions are not independent but build sequentially.
- **Institutional Layer (Layer 3):** Trust, legitimacy, and reputation, identified as equity dimensions in NGO models (Romero et al., Anselmsson et al.), bridge Layers 3 and 4.
- **Information Economics Layer (Layer 2):** Utility-based brand equity (Swait & Erdem) maps conceptually onto the credence goods / signalling logic of Layer 2 — brand equity reduces information asymmetry.
- **Resource Layer (Layer 6):** Loyalty and commitment in BE models correspond to donation participation, frequency, and amount outcomes.

## Sub-topic B connects to:
- **Behavioural Layer (Layer 5):** Brand equity dimensions are upstream determinants of attitude, subjective norms, and PBC — the core Layer 5 constructs. This confirms that the BE→Behavioural Layer causal path is empirically justified.
- **Brand Equity Layer (Layer 4) → Behavioural Layer (Layer 5):** The mechanism is: BE dimensions → brand attitude → TPB components → intention → behaviour. BEBA's cross-layer path runs from Layer 4 to Layer 5.

## Sub-topic C connects to:
- **Behavioural Layer (Layer 5):** The IBM's extended components (experiential/instrumental attitudes, injunctive/descriptive norms, self-efficacy/PBC, knowledge, salience, habit) map onto BEBA Layer 5 constructs of attitude, subjective norms, PBC, intention, knowledge, salience, constraints, and habit. This validates BEBA's choice of the IBM as the behavioural architecture.
- **Resource Layer (Layer 6):** Donation participation, frequency, and amount are the behavioural outcomes of the IBM chain. The meta-analytic evidence from White et al. (2023) confirms intention → behaviour in charitable giving.
- **Institutional Layer (Layer 3) → Behavioural Layer (Layer 5):** Trust, reputation, and CEO reputation effects function as institutional-level brand signals that feed into donation attitudes and norms (Lee & Kim, 2023; Kim & Han, 2020; Obadă et al., 2024).
- **Epistemic Layer (Layer 1):** Moral norm as a predictor of charitable giving connects to BEBA's bounded rationality framing — moral norm functions as a cognitive heuristic that short-circuits full deliberative attitude formation.

---

# Connections to Existing Models

## Faircloth model (FC_BF = familiarity, FC_BI = brand image, FC_BP = brand personality)
- Sub-topic A confirms: FC_BF (familiarity) parallels awareness — a foundational hierarchical node before image associations. The Keller network view and Romero et al. both position familiarity as the entry point.
- FC_BI (brand image) is the primary driver of brand attitude in the TPB integration (Wu et al., 2020; Zheng et al., 2025), supporting BEBA's Layer 4 → Layer 5 path from image to attitude.
- FC_BP (brand personality) is an antecedent of brand attitude in Wu et al. (2020), providing direct empirical support for its retention in the BEBA model.

## Boenigk & Becker model (BO_TR = brand trust, BO_CO = brand commitment)
- Trust is a confirmed mediator in hierarchical BE models (Anselmsson et al., 2017; Martín et al., 2019) and an antecedent of loyalty and PBC in CBBE–TPB integration (Wu et al., 2020).
- Multidimensional trust (Lee & Kim, 2023) in charitable organisations (ability, integrity, benevolence) is a direct empirical parallel to BO_TR; trust positively predicts donation attitudes and intentions.
- Brand commitment (BO_CO) maps to the loyalty/habit dimension at the output end of the BE hierarchy and to the "salience and habit" cell in the IBM mapping table.

## Romero et al. model (RO_BW = authenticity, RO_BR = reputation, RO_ID = donation intention)
- Romero et al. (2023) is a primary source in this review. The three-block donor-based BE model (familiarity → associations [authenticity, reputation, differentiation] → commitment → donation intention) is directly evidenced.
- RO_BR (reputation) is independently confirmed as influencing donation attitudes and intentions via TPB pathways (Kim & Han, 2020; Obadă et al., 2024).
- RO_BW (authenticity) is part of the associations block in Romero et al. but does not appear prominently in the TPB/IBM integration literature reviewed here; its link to IBM constructs is inferential.
- RO_ID (donation intention) is the direct outcome variable in the White et al. (2023) meta-analysis; the evidence base for intention as proximal predictor of actual donation is robust.

## TPB
- Sub-topics B and C provide extensive support for TPB as the behavioural architecture. Attitude, subjective norms, and PBC → intention → behaviour is confirmed for charitable giving by meta-analysis. Moral norm is a critical extension. The specific additions from BEBA's Behavioural Layer (knowledge, salience, constraints, habit from IBM) are supported by green purchase research but not directly for donation contexts.

## IBM (Fishbein & Yzer, 2003)
- IBM is the theoretical home of BEBA's Behavioural Layer constructs. The reviewed literature does not contain a direct IBM-labelled donation study but provides: (1) empirical validation of all IBM intention determinants in a near-donation context (green purchasing, Surucu et al., 2019); (2) convergent evidence from donation TPB studies that implement IBM-like extended constructs; (3) an explicit mapping table of IBM determinants to brand equity constructs (from the source document).
- The gap between the IBM and the charitable donation literature is the largest single theoretical gap for BEBA to address.

---

# Implications for Model Competition

BEBA's model needs to take a position on the following:

1. **Whether brand attitude toward the nonprofit is a strong or weak proximal driver of donation intention.** The evidence is mixed. In commercial contexts it is strong (meta-analysis); in nonprofit/donation contexts it may be dominated by moral norm and PBC. BEBA should model it as a mediated, not direct, path — with moral norm potentially outcompeting brand attitude in ethically engaged Austrian donor samples.

2. **Whether IBM adds explanatory value over extended TPB for BEBA's donation outcomes.** Given that donation research already uses IBM-like extended TPB, IBM's distinctiveness lies primarily in the salience/habit/knowledge direct behaviour determinants. If habit (repeat giving) and salience (awareness of giving opportunity) are explicitly included, IBM provides genuine added value over TPB.

3. **Whether the Romero et al. nonprofit BE model can be retained intact.** The familiarity → associations → commitment structure is coherent and aligns with the broader hierarchical evidence, but single-study status means BEBA should treat it as a working hypothesis, supplemented by the broader CBBE literature for dimension specification.

4. **How brand equity moderates vs. predicts TPB/IBM components.** BEBA's architecture should accommodate both causal roles — BE as antecedent of attitudes and norms, and BE as a moderator of control-intention paths.

---

# Open Research Questions

1. Does brand equity toward an Austrian nonprofit organisation predict donation attitude, and does this survive the inclusion of moral norm and PBC in the same model?
2. Which IBM behavioural determinants (knowledge, salience, constraints, habit) are most relevant in the Austrian charitable giving context, and do they mediate or moderate the intention–behaviour gap?
3. Does nonprofit brand activism (bravery vs. hypocrisy) affect brand equity dimensions differently for Austrian donors with varying moral foundations (care, fairness, loyalty, purity)?
4. Can the donor-based BE model (Romero et al., 2023) be replicated in an Austrian sample, and are its three blocks (familiarity, associations, commitment) confirmed?
5. Does multidimensional trust (ability, integrity, benevolence) in Austrian nonprofits operate through brand attitude or directly on donation intention?
6. Is the brand equity → PBC moderation effect (Foroudi et al., 2018) present in donation contexts — i.e., does strong nonprofit brand equity increase donors' sense of capability to give?
7. How do online vs. offline channels moderate the brand equity→intention mechanisms in Austrian nonprofit fundraising?
8. Do shared brand equity mechanisms (NGO–corporate cause partnerships) have differential effects on donor attitude and intention compared to standalone NGO branding?

---

# Suggested Ontology Entries

From sub-topic A: **Hierarchical Brand Equity Structure** (concept capturing the sequential ordering of awareness → image/associations → quality/value → loyalty/commitment); **Associative Network Memory** (mechanism by which brand associations activate and influence evaluation); **Shared Brand Equity** (equity arising from cross-entity association); **Donor-Based Brand Equity** (Romero et al. three-block NGO model); **Brand Bravery**; **Brand Hypocrisy**.

From sub-topic B: **Brand Attitude** (as TPB mediator between BE dimensions and intention); **PBC–Brand Equity Interaction** (moderating role of BE on control→intention path).

From sub-topic C: **Moral Norm** (for charitable giving; IBM-adjacent; should be added to BEBA Behavioural Layer); **Organisational Trust Multidimensionality** (ability/integrity/benevolence); **Donation Salience** (IBM direct behaviour determinant); **Green/Prosocial Habit** (IBM habit operationalisation in near-donation context); **CEO Reputation** (contextual reputational moderator of TPB structure).

---

# Suggested Dissertation Use

- **Chapter 2 (Literature Review), Section on Brand Equity Architecture:** Use sub-topic A to justify BEBA's hierarchical arrangement of Layer 4 constructs, citing Keller (1993, 2020), Romero et al. (2023), and the systematic reviews (Gutiérrez et al., 2023; Paschina, 2025).
- **Chapter 2, Section on Behavioural Mechanisms:** Use sub-topic B (Wu et al., 2020 meta-analysis) to justify the causal path from Brand Equity Layer to Behavioural Layer; use sub-topic C (White et al., 2023 meta-analysis) to justify choice of TPB/IBM as the Behavioural Layer architecture for charitable giving.
- **Chapter 2, Section on TPB–IBM for Charitable Giving:** Synthesise the fourth section (charitable donations) to establish the empirical foundation for each BEBA Layer 5 construct, noting the dominance of moral norm and the partial evidence for brand-level attitude effects.
- **Chapter 3 (Theoretical Framework):** Use the IBM mapping table (source sub-topic C) to formally justify the assignment of brand equity constructs to IBM components in BEBA's causal model.
- **Chapter 5 (Discussion):** Use the tension between moral norm dominance and brand attitude weakness (Mittelman & Rojas-Méndez, 2018; Kim & Han, 2020) to position BEBA's contribution as the first Austrian test of whether nonprofit brand equity survives moral norm inclusion.
- **Limitations:** Acknowledge the commercial-context bias of the CBBE–TPB evidence base (sub-topic B) and the absence of formal IBM-brand equity models in nonprofit contexts (sub-topic C gap).

---

# Confidence Assessment

| Dimension | Level | Justification |
|---|---|---|
| Conceptual clarity | High | CBBE, TPB, IBM, and moral norm constructs are well-defined and consistently operationalised across the reviewed studies; the mapping of BE to IBM components is logically coherent. |
| Empirical maturity | Medium | High for: hierarchical CBBE structure (commercial), TPB in charitable giving (meta-analytic), brand attitude as TPB mediator (meta-analytic). Medium for: nonprofit-specific BE models (Romero et al. single study), BE moderating PBC (single study). Low for: formal IBM–BE integration in nonprofit contexts (no direct evidence). |
| Relevance for BEBA | High | The three sub-topics collectively provide the structural, causal, and empirical foundations for all six BEBA layers; the main limitation is the commercial-context bias of sub-topic B and the absence of Austrian nonprofit-specific data in the reviewed set. |
