# Synthesised Knowledge Unit (SKU): Brand Factors and Donation Intention in Nonprofits and Charities

---

## Topic

This SKU synthesises empirical and theoretical knowledge on how nonprofit brand factors — brand image, brand personality, brand familiarity, brand trust, brand authenticity, brand identification, brand orientation, and brand equity — influence individuals' donation intention toward nonprofit organisations (NPOs) and charities. This domain is the core empirical target of the BEBA Research Platform.

---

## Scientific Relevance

Donation intention is the primary behavioural outcome variable in BEBA's Resource Layer. The reviewed literature provides the most direct empirical evidence for BEBA's central claim: that brand equity constructs at Layer 4 causally influence the giving decision pathway at Layer 5 and resource outcomes at Layer 6. This body of research is therefore foundational — not peripheral — to BEBA.

The topic sits at the intersection of nonprofit marketing, consumer psychology, and information economics. It addresses a practical problem of high societal importance: how organisations competing for charitable resources can communicate value credibly to donors who face high information uncertainty (credence goods problem). Across 50 studies spanning 2005–2025, a convergent but nuanced picture has emerged: brand factors matter, trust is the dominant mechanism, and context boundary conditions are real.

---

## Historical Development

The scientific trajectory of this field follows three recognisable phases:

**Phase 1 — Foundation (2005–2012):** Seminal work established the applicability of commercial brand constructs to the nonprofit domain. Venable et al. (2005) validated a charity-specific brand personality scale. Sargeant et al. (2008) demonstrated the empirical link between personality traits and giving behaviour. Michel & Rieunier (2012) established brand image as a quantitatively significant predictor (up to 31% variance explained) of monetary donation intent. These studies established that commercial brand theory could be adapted — not merely imported — for nonprofit contexts.

**Phase 2 — Mechanism Identification (2015–2020):** Research shifted from testing direct effects to identifying the mediating architecture. Michaelidou et al. (2015) introduced moderation by giving type (money vs. time) and donor involvement. Wymer & Akbar (2018) added brand authenticity as a direct predictor. Katz (2018) and Kim & Han (2020) introduced boundary conditions via reputation and CEO signals. Hou et al. (2009) positioned donor self-concept as a mediator of brand equity effects. Gregory et al. (2019) and Ngo et al. (2021) extended the framework to brand salience and new donor decision-making.

**Phase 3 — Expansion and Specification (2020–2025):** This phase is marked by construct proliferation (brand orientation, brand heritage, brand anthropomorphism, brand strength) and contextual extension (social media, m-payment, faith-based, cross-cultural). Millán et al. (2023) integrated brand identification and past behaviour. Romero et al. (2023) articulated a donor-based brand equity model for NGOs. Crawford & Jackson (2025) formalised the donor–charity congruence pathway. Throughout, trust has remained the dominant and most consistently replicated mediator.

---

## Major Theoretical Schools

Three theoretical schools are identifiable in the reviewed literature:

**1. Brand Equity School (Aaker/Keller tradition applied to nonprofits):**
Treats brand equity as a multi-dimensional asset (awareness, image, perceived quality, loyalty) and argues that each dimension translates into donor behavioural outcomes. Hou et al. (2009) and Romero et al. (2023) represent this tradition. BEBA's Brand Equity Layer (Layer 4) aligns directly with this school. Faircloth's model (FC_BI, FC_BP, FC_BF) also derives from this school.

**2. Social Identity / Self-Congruence School:**
Argues that donors give because the charity brand matches their self-concept (actual or ideal). Brand personality congruence acts as the mechanism. Venable et al. (2005), Sargeant et al. (2008), Crawford & Jackson (2025), and Millán et al. (2023) draw on this tradition. This school maps onto BEBA's Behavioural Layer (Layer 5) through donor identity processes and attitude formation.

**3. Trust-Mediation School:**
Holds that brand factors do not directly cause donation intention but operate through trust. Trust is the cognitive shortcut that reduces the information asymmetry inherent in charitable giving (a credence good). Bilgin & Kethüda (2022), Ha et al. (2022), Kutlu & Özcan (2024), and García-Madariaga et al. (2023) all build on this framework. This school bridges BEBA's Information Economics Layer (Layer 2) and Institutional Layer (Layer 3) with the Brand Equity Layer (Layer 4).

These schools are not mutually exclusive; most recent studies draw on two or more simultaneously. The trust-mediation school currently produces the most replicable and generalisable findings.

---

## Canonical Definitions

See also Evidence Map (Step 1). Key synthesised definitions:

- **Brand Image (nonprofit):** The aggregate mental representation held by a donor or prospective donor of a charity, composed of functional associations (competence, service quality), emotional associations (warmth, inspiration), and typicality (degree to which a charity represents its category) (Michel & Rieunier, 2012; Bilgin & Kethüda, 2022).

- **Brand Personality (nonprofit):** Charity-specific human-like trait attributions; validated dimensions for NPOs are integrity, nurturance, and sophistication, which differ from Aaker's (1997) commercial dimensions (Venable et al., 2005; Sargeant et al., 2008; Shehu et al., 2016).

- **Brand Familiarity:** Prior exposure-based knowledge of a charity that reduces perceived uncertainty and increases willingness to donate, primarily via trust and credibility pathways (Katz, 2018; García-Madariaga et al., 2023).

- **Brand Trust:** Donor's confidence in a charity's benevolence and reliability; the single most consistently supported mediating variable in the reviewed literature (Bilgin & Kethüda, 2022; Millán et al., 2023; Kutlu & Özcan, 2024).

- **Brand Authenticity:** The perceived genuineness and mission-integrity of a charity brand; distinct from trust in that it captures continuity and transparent communication rather than reliability expectations (Wymer & Akbar, 2018).

- **Brand Identification:** The donor's psychological sense of unity or overlap with a charity's brand identity; related to social identity theory (Millán et al., 2023).

- **Brand Orientation:** An internal organisational strategy variable reflecting the NPO's commitment to using branding as a core management process; primarily an antecedent to donor perceptions rather than a perception itself (Da Silva et al., 2020; Ramayanti et al., 2024).

- **Brand Equity (donor-based):** The incremental value of a charity's brand to donor decision-making beyond functional attributes; encompasses awareness, associations, perceived quality, and loyalty (Romero et al., 2023).

- **Donation Intention:** A donor's self-reported likelihood to contribute money (or time) to a specific charity; the primary dependent variable in this literature and BEBA's Layer 5 outcome variable.

---

## Core Mechanisms (Antecedents → Mediators → Moderators → Outcomes)

### Primary Path: Brand Image → Trust → Donation Intention
The most robustly supported causal chain. Brand image (formed via organisational communication, social media, and past experience) elevates brand trust, which in turn drives donation intention. Supported by Bilgin & Kethüda (2022), Millán et al. (2023), Ha et al. (2022).

### Secondary Path: Brand Familiarity → Credibility/Trust → Donation Intention
Repeated exposure to a charity brand reduces perceived uncertainty (information economics mechanism). Credibility and trust are sequential mediators. Supported by García-Madariaga et al. (2023), Kusumasondjaja & Krisnawati (2024), Katz (2018). Familiarity alone without positive associations is insufficient (Romero et al., 2023).

### Tertiary Path: Brand Personality/Congruence → Attitude → Donation Intention
Perceived match between donor self-concept and charity personality traits generates a positive attitude toward the charity, elevating donation intention. Supported by Venable et al. (2005), Sargeant et al. (2008), Crawford & Jackson (2025).

### Quaternary Path: Brand Orientation (internal) → Brand Image → Attitude → Donation Intention
An NPO's internal brand orientation shapes the external brand image perceived by donors, which flows through attitude toward charity to donation intention. This is a full mediated chain. Supported by Da Silva et al. (2020), Ramayanti et al. (2024).

### Moderators:
- CEO/organisational reputation moderates the brand → intention relationship (Kim & Han, 2020; Katz, 2018)
- Donor involvement moderates attitude/salience effects (Michaelidou et al., 2015)
- Giving type (money vs. time) moderates which brand dimensions are relevant (Michaelidou et al., 2015)
- Intrinsic religiosity moderates familiarity → credibility in Islamic contexts (Kusumasondjaja & Krisnawati, 2024)

---

## Empirical Evidence

**Convergent evidence (high confidence):**
- Brand image is the single most studied predictor; its positive effect on donation intention is replicated across multiple countries, methods (SEM, conjoint, experiment), and time periods (Michel & Rieunier, 2012; Millán et al., 2023; Paço et al., 2014; Da Silva et al., 2020).
- Brand trust functions as a dominant mediator in virtually all recent studies. The trust-mediation hypothesis is now close to a settled empirical regularity in this literature.

**Moderately supported evidence:**
- Brand personality traits (especially integrity and nurturance) predict giving via self-congruence; scale validated for nonprofits (Venable et al., 2005).
- Brand familiarity increases willingness to donate but only when paired with positive associations and/or trust.
- Brand identification adds explanatory power beyond brand image, especially when past behaviour is controlled (Millán et al., 2023).
- Brand authenticity has direct predictive power over support intentions (Wymer & Akbar, 2018).

**Emerging evidence (lower replication):**
- Brand heritage → trust → donation intention (Kutlu & Özcan, 2024)
- Brand anthropomorphism → support intention (Ha et al., 2022; Dalman & Ray, 2021)
- Donor–charity congruence as a formal pathway independent of general brand image (Crawford & Jackson, 2025)

**Known null/boundary evidence:**
- Familiarity alone: direct effect absent or weak without positive associations (Romero et al., 2023)
- Negative CEO reputation: disrupts branding → donation link (Kim & Han, 2020)

---

## Theoretical Tensions

**Tension 1 — Direct vs. mediated effects of brand image:**
Some studies report a direct path from brand image to donation intention (Michel & Rieunier, 2012); others find that trust fully mediates this path (Bilgin & Kethüda, 2022). The discrepancy likely reflects model specification differences (inclusion/exclusion of trust in the model) and may also reflect genuine variability in donor involvement levels. This is unresolved.

**Tension 2 — Brand familiarity as sufficient vs. necessary-but-insufficient condition:**
The Garcia-Madariaga et al. (2023) and Katz (2018) findings support familiarity as a driver of willingness to donate, while Romero et al. (2023) find no direct effect without positive associations. These findings are not fully reconciled in the literature. The trust-mediation hypothesis may resolve this: familiarity works through trust, and without trust, familiarity has no independent effect.

**Tension 3 — Self-congruence vs. instrumental attitude as the mechanism for brand personality effects:**
The self-congruence school (Venable et al., 2005; Crawford & Jackson, 2025) locates brand personality effects in identity processes, while attitude-based explanations (Da Silva et al., 2020) locate them in evaluative beliefs. Both mechanisms may operate simultaneously and may be complementary rather than competing.

**Tension 4 — Brand orientation as antecedent vs. component of brand equity:**
Brand orientation (Da Silva et al., 2020) is positioned as an internal organisational antecedent that shapes donor perceptions. However, some brand equity frameworks treat orientation-related variables as part of the equity construct itself. This definitional ambiguity creates model specification challenges for BEBA.

**Tension 5 — Familiarity effects: Faircloth model (FC_BF) vs. Romero model (RO_BW/authenticity):**
Faircloth's model treats brand familiarity (FC_BF) as a direct component of brand equity and a pathway to donation intention. Romero et al.'s donor-based brand equity model positions authenticity (RO_BW) as a key dimension, and their findings suggest familiarity alone does not suffice. These two models make different predictions about the role of familiarity in the donation pathway, creating a direct model competition relevant to BEBA.

---

## Boundary Conditions

1. **Trust dependency of familiarity effects:** Brand familiarity only reliably influences donation intention when it generates or co-occurs with trust. This boundary condition is directly relevant to BEBA's mapping of FC_BF (Faircloth familiarity) relative to BO_TR (Boenigk & Becker brand trust).

2. **Reputation as a ceiling/floor variable:** A charity with a severely negative reputation or CEO scandal can have its branding effects nullified. This suggests that institutional legitimacy (BEBA Layer 3) sets an upper boundary on what brand equity (Layer 4) can achieve.

3. **Giving modality specificity:** Brand image appears primarily relevant to monetary donation decisions; typicality may matter more for volunteering. This boundary condition limits the generalisability of brand image findings across BEBA's full Resource Layer.

4. **Donor involvement as moderator:** Low-involvement donors may be influenced primarily by salience and familiarity (heuristic processing, consistent with BEBA's Epistemic Layer); high-involvement donors appear to rely more on attitude-based processing. This maps directly onto BEBA's bounded rationality framing.

5. **Cultural context:** Current evidence is predominantly from Western, educated, and relatively secular populations. Cross-cultural generalisability — including to the Austrian DACH context — is unverified.

6. **Organisational size:** The mechanisms through which small/local charities achieve brand effects may differ from large/global organisations due to resource constraints and lower baseline familiarity levels (Stebbins & Hartman, 2013). Small charities in Austria (the BEBA context) face this challenge acutely.

---

## Criticism

**Methodological criticism:**
- Heavy reliance on self-reported donation intention rather than actual giving behaviour. Intention-behaviour gaps in charitable giving are documented; studies measuring intentions may overestimate effect sizes.
- Cross-sectional SEM designs dominate, preventing causal inference beyond the structural model level. Experimental and longitudinal designs remain rare.
- Most studies are conducted in single-country, single-organisation contexts, limiting external validity.
- Publication bias is a realistic concern: null findings for brand factors may be underreported.

**Conceptual criticism:**
- Construct proliferation: brand image, brand identity, brand personality, brand authenticity, brand equity, and brand strength are sometimes treated as distinct constructs and sometimes conflated. Discriminant validity across these constructs is not consistently established.
- Brand orientation is an organisational-level variable, while all other brand constructs in this literature are donor-perception-level variables. Mixing levels of analysis within single SEM models is a theoretical weakness not always acknowledged.
- The reviewed literature rarely engages with the credence goods problem at a formal level; trust is invoked as a mechanism but the underlying information economics logic (why trust matters) is not always theorised.

**BEBA-specific critique:**
- The reviewed literature does not disaggregate the Austrian giving context. Austrian donors may exhibit different trust relationships, cultural distance from charity, and familiarity patterns compared to British, Brazilian, or Vietnamese samples that dominate the reviewed literature.

---

## Connections to BEBA (layer placement, causal links)

| Construct | BEBA Layer | Role in BEBA |
|---|---|---|
| Brand Image | Layer 4 (Brand Equity) | Core brand equity dimension; antecedent to trust and attitude; directly maps to FC_BI |
| Brand Personality | Layer 4 (Brand Equity) | Core brand equity dimension; maps to FC_BP and BO_CO (commitment via congruence) |
| Brand Familiarity | Layer 4 (Brand Equity) | Core brand equity dimension; maps to FC_BF; boundary condition: requires trust co-activation |
| Brand Trust | Layer 3 (Institutional) / Layer 4 (Brand Equity) | Dual-layer: institutional trust (Layer 3) and brand-specific trust (Layer 4 = BO_TR); dominant mediator |
| Brand Authenticity | Layer 3 (Institutional) / Layer 4 (Brand Equity) | Maps to RO_BW; bridges institutional legitimacy and brand equity |
| Brand Identification | Layer 5 (Behavioural) | Donor-side construct; reflects identity-based attitude; feeds into donation intention |
| Brand Orientation | Layer 3 (Institutional) / Layer 4 antecedent | Internal NPO strategy; antecedent to perceived brand equity; not currently in BEBA models |
| Donation Intention | Layer 5 (Behavioural) | Primary outcome in the reviewed literature = RO_ID, TPB's intention variable |
| Donor Self-Concept | Layer 5 (Behavioural) | Mediates brand equity → intention (Hou et al., 2009); relates to PBC and identity in TPB |
| Reputation | Layer 3 (Institutional) | Moderates brand → intention; maps to RO_BR in Romero model |
| CEO Reputation | Layer 3 (Institutional) | Moderates branding effectiveness; a legitimacy signal |
| Attitude toward charity | Layer 5 (Behavioural) | Mediates brand orientation/image → intention; maps to TPB's attitude component |
| Brand Salience | Layer 5 (Behavioural) | Category-level awareness heuristic; maps to BEBA's knowledge/salience variable in Behavioural Layer |

**Causal architecture relevant to BEBA:**

The reviewed literature most strongly supports the following causal chain, which BEBA should treat as the empirical baseline:

`Brand Orientation (L3) → Brand Image / Familiarity / Personality (L4) → Brand Trust (L3/L4 bridge) → Attitude toward Charity (L5) → Donation Intention (L5) → Donation Behaviour (L6)`

Trust sits at the interface of Layers 3 and 4 and is the single most load-bearing mechanism in this literature.

---

## Connections to Existing Models (Faircloth, Boenigk & Becker, Romero, TPB, IBM)

**Faircloth Model (FC_BI, FC_BP, FC_BF):**
The reviewed literature strongly corroborates Faircloth's three dimensions. Brand image (FC_BI) is the most empirically supported predictor of donation intention across all studies. Brand personality (FC_BP) is supported with nonprofit-specific scale validation (Venable et al., 2005). Brand familiarity (FC_BF) is supported but with the critical boundary condition that positive associations/trust must co-occur. The Romero model challenges the FC_BF assumption by showing familiarity without trust has no direct effect.

**Boenigk & Becker Model (BO_TR, BO_CO):**
Brand trust (BO_TR) emerges as the dominant mediating mechanism in this literature, providing extremely strong empirical validation for Boenigk & Becker's inclusion of trust as a core brand equity dimension. Brand commitment (BO_CO) has a weaker evidential base in this review; it receives indirect support through the brand identification and donor–charity congruence pathways (Millán et al., 2023; Crawford & Jackson, 2025) but is not directly operationalised in most reviewed studies.

**Romero Model (RO_BW = authenticity, RO_BR = reputation, RO_ID = donation intention):**
Authenticity (RO_BW) receives direct empirical support from Wymer & Akbar (2018). Reputation (RO_BR) is supported as a moderator (Kim & Han, 2020; Katz, 2018) and as a component of brand equity (Romero et al., 2023). Donation intention (RO_ID) is the standard outcome variable across all 50 studies. The Romero model's boundary condition finding (familiarity insufficient alone) is directly evidenced by Romero et al. (2023) themselves.

**Theory of Planned Behaviour (TPB):**
Attitude toward charity is the most proximal TPB variable addressed in this literature and is consistently supported as a mediator between brand factors and intention. Subjective norms are less frequently examined in this brand-specific literature (they appear primarily in Kim & Han, 2020). Perceived behavioural control (PBC) is rarely operationalised in nonprofit brand studies. The TPB therefore provides a receiving framework for brand effects: brand factors feed into TPB components (attitude primarily, subjective norms secondarily), which then determine intention.

**Integrated Behavioural Model (IBM):**
The IBM's additional variables — salience/knowledge of behaviour, habit, constraints — receive partial coverage. Brand salience is directly addressed by Gregory et al. (2019) and Ngo et al. (2021). Habit/past behaviour is addressed by Millán et al. (2023) who include past behaviour as a covariate. Constraints and knowledge are not frequently examined in the brand-specific literature. The IBM framework is not explicitly invoked by most reviewed studies, but its constructs are implicitly present.

---

## Implications for Model Competition

The reviewed literature generates the following implications for competition among BEBA's incorporated models:

1. **Boenigk & Becker's trust construct (BO_TR) outperforms Faircloth's familiarity construct (FC_BF) as a predictor of donation intention.** Trust is consistently a stronger and more proximal predictor; familiarity requires trust as a relay. This suggests that in BEBA model specification, BO_TR should be positioned as a mediator between FC_BF and donation intention, not as a parallel predictor.

2. **Brand image (FC_BI) is the strongest single brand equity predictor of donation intention** across all studies, giving Faircloth's image dimension priority over the personality dimension (FC_BP) in terms of variance explained. However, personality matters for self-congruence mechanisms.

3. **Romero's authenticity dimension (RO_BW) adds explanatory power** that is not captured by the Faircloth or Boenigk & Becker models. Authenticity is conceptually distinct from trust (it reflects perceived continuity and mission integrity rather than reliability expectations) and should be maintained as a separate construct in BEBA.

4. **Romero's reputation construct (RO_BR) appears primarily as a moderator** of the brand → intention relationship rather than as a direct predictor in the reviewed literature. This has implications for how RO_BR should be positioned in BEBA: as a boundary condition variable rather than a main effect predictor.

5. **Brand orientation (Da Silva et al., 2020) is not represented in any of the three canonical BEBA models** (Faircloth, Boenigk & Becker, Romero). It is an internal NPO-level construct that antecedes all three models' brand perception dimensions. BEBA may need to incorporate it as an organisational-level input variable in Layer 3 or as an Institutional Layer antecedent.

---

## Open Research Questions

1. What is the causal ordering of brand trust vs. brand authenticity in the pathway from brand image to donation intention? Do they mediate sequentially, in parallel, or substitute for each other in different donor segments?

2. Does the brand → trust → donation intention pathway replicate in the Austrian DACH context, where institutional trust levels and giving culture differ from the predominantly Western anglophone samples in this literature?

3. Can the familiarity boundary condition (familiarity requires trust to affect intention) be fully explained by information economics theory, or are there identity-based or heuristic mechanisms that also account for the null direct effect?

4. How does digital/social media interaction modify the traditional brand equity → trust → intention pathway? Does social media engagement create a distinct channel or merely amplify the established mechanisms?

5. Is the brand commitment construct (BO_CO) distinct from brand identification (Millán et al., 2023) in terms of predictive power over donation intention? If not, they may be redundant constructs in BEBA's architecture.

6. How do the branding effects identified in this literature translate to actual giving behaviour over time, particularly for repeat donors (habit formation, Layer 5 in BEBA)?

7. Does brand orientation operate primarily through brand image, or does it have direct paths to trust and authenticity that bypass image?

---

## Suggested Ontology Entries

The following constructs are sufficiently mature and well-evidenced for inclusion in BEBA's concept ledger (detailed entries in Step 3/Ontology file):

1. **Brand Image (nonprofit)** — High priority; core empirical predictor; maps to FC_BI
2. **Brand Trust (nonprofit)** — High priority; dominant mediator; maps to BO_TR
3. **Brand Personality (nonprofit)** — High priority; validated scale; maps to FC_BP
4. **Brand Familiarity** — High priority; established with boundary conditions; maps to FC_BF
5. **Brand Authenticity** — Medium-high priority; emerging direct predictor; maps to RO_BW
6. **Brand Identification** — Medium priority; emerging construct; feeds into Layer 5
7. **Donation Intention** — High priority (already in BEBA as RO_ID); should be confirmed as the canonical outcome variable
8. **Attitude toward Charity** — Medium-high priority; TPB attitude node mediating brand → intention; maps to TPB attitude
9. **Brand Orientation** — Medium priority; organisational antecedent not yet in BEBA models
10. **Brand Heritage** — Low-medium priority; emerging construct; merits monitoring

---

## Suggested Dissertation Use

**Chapter 2 (Literature Review):** This SKU provides the theoretical grounding for BEBA's Brand Equity Layer and its connection to the Behavioural Layer. The core mechanism section (trust as dominant mediator, image as primary predictor) should anchor the chapter's synthesis of brand equity effects on donation intention.

**Chapter 3 (Conceptual Model Development):** The model competition analysis (Faircloth vs. Boenigk & Becker vs. Romero) provides the theoretical justification for the specific causal paths proposed in BEBA's integrated model. The boundary conditions (familiarity requires trust; reputation as moderator; involvement as moderator) should be stated as explicit hypotheses.

**Chapter 4 (Measurement):** The scale inventory (Venable et al., 2005 brand personality; Bilgin & Kethüda, 2022 brand trust; Wymer & Akbar, 2018 authenticity) provides direct sources for questionnaire adaptation to the Austrian context.

**Chapter 5 (Empirical Study):** The gaps identified (Austrian context, longitudinal actual behaviour, small charity applicability) directly justify the original empirical contribution of the dissertation. BEBA's Austrian small-charity context addresses all three primary gaps in this literature.

---

## Confidence Assessment

| Dimension | Rating | Justification |
|---|---|---|
| Conceptual clarity | **High** | Core constructs (brand image, trust, personality, intention) are well-defined with validated scales; newer constructs (orientation, anthropomorphism) are less settled |
| Empirical maturity | **Medium-High** | 50 studies with cross-methodological convergence on image and trust; however, cross-sectional and self-report limitations are pervasive; actual behaviour outcomes are rare |
| Relevance for BEBA | **High** | This literature directly addresses BEBA's core causal claim (brand equity → donation intention); trust as dominant mediator, image as primary predictor, and personality/familiarity/authenticity as secondary predictors are all directly incorporated in BEBA's model architecture |
