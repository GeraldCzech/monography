# Topic

Theory of Planned Behavior (TPB) and its extensions as the primary framework for explaining charitable donation intention and behavior — synthesised for integration into the BEBA Research Platform's Behavioural Layer.

---

# Scientific Relevance

TPB is the most empirically validated social-cognitive framework for predicting charitable giving. The breadth of evidence — a meta-analysis pooling 50 studies across monetary, blood/organ, digital, and volunteering donation types (White et al., 2023), supplemented by 49 additional empirical papers spanning 2007–2025 — establishes it as the foundational model for BEBA's Behavioural Layer. Its constructs (attitude, subjective norm, PBC, and intention) form the structural backbone of BEBA's donation decision process and directly interface with brand equity antecedents operating in the layers above.

The model's parsimony (three predictors, one mediator, one outcome) makes it tractable for dissertation-level empirical testing, while its recognized limitations (intention–behavior gap, cultural boundary conditions, extension possibilities via moral norm and trust) generate the research agenda that the BEBA project partially addresses.

---

# Historical Development

TPB was introduced by Icek Ajzen (1991) as a refinement of the Theory of Reasoned Action (TRA; Fishbein & Ajzen, 1975), which posited only attitude and subjective norm as determinants of intention. The key innovation of TPB was the addition of **Perceived Behavioral Control (PBC)** to account for behaviors that are not fully volitional — a direct response to TRA's failure in contexts involving resource or capability constraints.

The Integrated Behavioral Model (IBM; Fishbein & Yzer, 2003), referenced in the BEBA framework, extends TPB further by incorporating **knowledge**, **salience**, and **habit** as additional predictors of behavior beyond intention and PBC — recognising that well-formed intentions do not always translate into action without environmental and habitual support.

In charitable giving research, the extension trajectory moved from testing the base model (Smith & McSweeney, 2007) through adding moral norms (Linden, 2011), self-identity (Knowles et al., 2012), past behavior (Hyde et al., 2013), religiosity (Kashif & Run, 2015), trust (Lee & Kim, 2023), and digital platform credibility (Li et al., 2022), culminating in meta-analytic confirmation of the extended model's superiority (White et al., 2023).

---

# Major Theoretical Schools

**1. Standard TPB (Ajzen tradition):** Attitude + Subjective Norm + PBC → Intention → Behavior. The parsimonious baseline, replicated extensively across donation types. Explains ~44% of variance in intention, ~19% in behavior (White et al., 2023).

**2. Extended TPB — Moral Self School:** Adds moral norms and/or self-identity to the standard triad, arguing that charitable behavior is ethically motivated beyond mere social conformity (Linden, 2011; Kim & Han, 2020; Knowles et al., 2012). This extension raises explained variance to ~52% for intention and is particularly well-supported for prosocial behaviors.

**3. Extended TPB — Habit/Past Behavior School:** Adds past behavior as a predictor of both intention and behavior directly, acknowledging habitual giving patterns that are not fully mediated by deliberative attitude formation (Hyde et al., 2013; Knowles et al., 2012).

**4. Extended TPB — Trust/Credibility School:** Adds trust in the charitable organization or platform as an antecedent of attitude and intention, recognising that information asymmetry and credence good properties of charitable services necessitate trust formation prior to giving (Lee & Kim, 2023; Li et al., 2022). This school bridges TPB and Information Economics logic.

**5. Integrated Behavioral Model (IBM; Fishbein & Yzer, 2003):** The closest formal successor to TPB, incorporating knowledge, salience, habits, and constraints alongside TPB's core constructs. Directly referenced in BEBA's Behavioural Layer construct ledger.

**6. Non-Western/Culturalist Critique:** Questions the cross-cultural universality of TPB, showing that income, happiness, and collectivist norms may dominate or displace the standard triad in some contexts (Musamuxamedov et al., 2025; Anggraeni & Kuklienė, 2024).

---

# Canonical Definitions

**Attitude (toward donating):** An individual's overall positive or negative evaluative response to performing the donation behavior, formed from beliefs about consequences and value placed on those consequences.

**Subjective Norm:** The perceived social pressure from significant others (family, peers, community) to perform or not perform the donation behavior, weighted by motivation to comply.

**Perceived Behavioral Control (PBC):** The individual's perceived ease or difficulty of performing the donation behavior, encompassing both self-efficacy (capability) and controllability (external constraints). PBC can directly predict behavior independently of intention when resources and opportunities are limiting.

**Moral Norm (Personal Norm):** A sense of personal moral obligation to donate, tied to one's ethical values and identity rather than to external social expectations. Distinct from and frequently more predictive than subjective norm in prosocial contexts.

**Donation Intention:** The motivational readiness to perform a donation in the foreseeable future; the proximal cognitive antecedent of donation behavior.

**Actual Donation Behavior:** The enacted giving act — whether monetary, in-kind, blood/organ, or time. Distinguished from intention by the intention–behavior gap.

---

# Core Mechanisms: Antecedents → Mediators → Moderators → Outcomes

**Antecedents (first-order predictors of Intention):**
- Attitude toward donating (positive evaluation)
- Subjective norm (social pressure to give)
- Perceived Behavioral Control (financial/logistical capacity and self-efficacy)
- Moral norm / personal norm (ethically grounded obligation)
- Past donation behavior (habitual activation)
- Self-identity as a donor
- Trust in charitable organization / platform credibility

**Mediator:**
- Donation Intention (fully mediates between the antecedents above and actual donation behavior in the standard TPB structure; attitude partially mediates trust → intention in extended models)

**Moderators:**
- Cultural context (religiosity, collectivism, income level)
- Donation type (monetary / blood-organ / digital / time)
- Platform/organizational trust level (especially in digital contexts)
- Nonprofit reputation (positive vs. negative CEO or organizational reputation)
- Message involvement and preexisting charitable beliefs

**Outcomes:**
- Donation intention (primary, more reliably measured)
- Actual donation behavior (participation, frequency, amount — the ultimate outcome but harder to predict from intention alone)

---

# Empirical Evidence

The strongest empirical anchor is White et al. (2023), a systematic review and meta-analysis of 50 studies covering diverse populations, donation types, and methodologies. Key quantitative findings:

- Standard TPB (attitude + subjective norm + PBC): R² = **0.44** for intention
- Extended TPB including moral norm: R² = **0.52** for intention
- Intention → behavior: R² = **0.19**
- PBC is consistently the **strongest single predictor** of intention (White et al., 2023; Smith & McSweeney, 2007)
- Moral norm consistently outperforms subjective norm in prosocial/donation contexts (Linden, 2011; Kim & Han, 2020)
- Trust improves prediction of attitude and intention in nonprofit and digital contexts (Lee & Kim, 2023; Li et al., 2022)
- Past behavior and self-identity add incremental predictive power for young donors (Knowles et al., 2012; Hyde et al., 2013)
- Cultural outliers: In Uzbekistan, income and happiness predicted charitable giving while classic TPB constructs did not (Musamuxamedov et al., 2025)

The research is well-replicated at the level of intention prediction. The behavior prediction evidence is comparatively thin, being dependent almost entirely on the intention–behavior correlation and providing no intervention-level mechanism.

---

# Theoretical Tensions

**1. Subjective norm vs. moral norm:** The social norm component of standard TPB is routinely outperformed by moral/personal norm in donation contexts. This calls into question whether "subjective norm" as operationalised in TPB surveys captures the ethically relevant normative pressure for charitable giving. The tension between other-directed and self-directed norms is unresolved in the literature.

**2. PBC as self-efficacy vs. controllability:** PBC conflates two distinct facets — capacity (can I do this?) and controllability (is this up to me?). These may operate differently for financial donations (controllability dominant) vs. blood/organ donation (self-efficacy dominant). Reviewed studies do not consistently disaggregate these dimensions.

**3. Intention–behavior gap:** The model's claim to predict behavior is undermined by the low R² for actual behavior (~19%). This is variously attributed to unmeasured constraints (IBM's "environmental constraints"), habit competition, temporal distance between intention measurement and behavior, and the absence of implementation intentions. No reviewed study tests an intervention that successfully closes this gap in a charitable giving context.

**4. Trust as antecedent vs. moderator:** The trust literature treats trust both as an antecedent of attitude (shaping how the organization's request is evaluated) and as a direct predictor of intention independent of attitude — its precise structural position in relation to TPB constructs is contested.

**5. Universality vs. cultural specificity:** The model performs robustly in Western and some Middle Eastern samples but shows no reliable predictive power in at least one non-Western context (Uzbekistan). Whether this reflects model misspecification, cultural measurement non-equivalence, or genuine substantive differences in donation drivers remains unresolved.

---

# Boundary Conditions

- TPB is most valid in **voluntary, deliberative** donation contexts where donors have time to form attitudes and perceive control over their resources
- Its validity decreases in **impulsive, digital, or socially pressured** giving contexts (birthday fundraisers, emergency campaigns)
- Standard TPB underperforms in **low-income**, **high-religiosity**, and **collectivist** cultural contexts where norms are structurally embedded rather than individually weighed
- The model better captures **first-time or infrequent donors** reasoning through the decision; for habitual donors, past behavior and habit mechanisms may dominate
- Cross-sectional designs cannot establish causality; the assumption that attitude → intention → behavior is directional and not reciprocal is theoretically motivated but not tested longitudinally in this literature

---

# Criticism

1. **Intention–behavior gap is theoretically unresolved within TPB:** Ajzen's original model offers no mechanism for why strongly positive intentions fail to translate to behavior; this gap requires external theoretical resources (implementation intentions, habit theory, dual-process models).

2. **Subjective norm is consistently the weakest predictor** in donation research yet is retained as a core construct; critics argue it should be disaggregated into descriptive norm, injunctive norm, and moral norm to capture prosocial motivation adequately.

3. **The model is intentionalist:** It privileges deliberative, planned cognition and has limited scope for explaining spontaneous, emotionally triggered, or habitual giving.

4. **Measurement heterogeneity:** Different studies operationalize PBC, attitude, and intention with varying item counts and anchors, reducing meta-analytic comparability.

5. **Cross-sectional dominance:** The near-total absence of longitudinal designs in the reviewed literature means that causal sequence assumptions are untested.

6. **Western-centricity:** The cumulative sample is disproportionately drawn from Western, educated, relatively affluent populations, limiting global generalizability.

---

# Connections to BEBA

## Layer Placement

TPB constructs map directly onto BEBA's **Behavioural Layer (Layer 5)**:

| TPB/Extended TPB Construct | BEBA Behavioural Layer Construct |
|----------------------------|----------------------------------|
| Attitude toward donating | Attitude |
| Subjective norm | Subjective norms |
| Perceived Behavioral Control | PBC |
| Donation intention | Donation intention |
| Moral norm | (currently unlisted — candidate for addition) |
| Past behavior / habit | Habit |
| Knowledge, salience, constraints | Knowledge; salience; constraints (via IBM) |

## Causal Links to BEBA Layers

- **Brand Equity Layer (Layer 4) → Behavioural Layer (Layer 5):** Brand image, brand trust, and brand credibility (Faircloth, Boenigk & Becker, Romero) shape the **attitude toward donating** to a specific organization and **trust** as a TPB extension antecedent. A favorable brand reduces perceived uncertainty, which relaxes the financial/psychological constraints captured by PBC.

- **Institutional Layer (Layer 3) → Behavioural Layer (Layer 5):** Institutional trust and legitimacy perceptions provide the foundation for the **trust** variable that extends TPB (Lee & Kim, 2023) and correspond to the subjective norm component insofar as institutional reputation signals socially endorsed giving behavior.

- **Information Economics Layer (Layer 2) → Behavioural Layer (Layer 5):** Credence good properties of nonprofits create information asymmetry that TPB's PBC construct partially captures (donors uncertain about impact may perceive low control). Signalling (brand credibility, transparency) reduces this asymmetry and elevates PBC and attitude.

- **Epistemic Layer (Layer 1) → Behavioural Layer (Layer 5):** Bounded rationality and heuristics are consistent with PBC's self-efficacy dimension; donors use brand heuristics and moral shortcuts (moral norm) rather than comprehensive benefit calculation.

- **Behavioural Layer (Layer 5) → Resource Layer (Layer 6):** Donation intention → actual donation participation, frequency, and amount — the ultimate BEBA outcome measures.

## Key BEBA Implication

This literature review provides the evidence base to **activate** the four constructs in BEBA's Behavioural Layer Construct Ledger that are currently listed as "planned": **attitude**, **subjective norms**, **PBC**, and **donation intention**. The meta-analytic effect sizes (R² = 0.44 for intention, 0.19 for behavior) serve as benchmarks for BEBA's dissertation empirical model.

---

# Connections to Existing Models

## Faircloth Model (FC_BI, FC_BP, FC_BF)
Brand image (FC_BI), brand personality (FC_BP), and brand familiarity (FC_BF) are expected to shape **attitude toward donating** to the organization by influencing how favorably the donation behavior is evaluated. Familiarity reduces cognitive effort in attitude formation; brand personality congruence elevates prosocial self-identity alignment.

## Boenigk & Becker (BO_TR, BO_CO)
Brand trust (BO_TR) and brand commitment (BO_CO) map onto the trust-extension of TPB (Lee & Kim, 2023). BO_TR is both an antecedent of attitude and a direct antecedent of donation intention, consistent with how Lee & Kim (2023) model trust's multidimensional effects. BO_CO may additionally reinforce moral norm through identity commitment to the organization.

## Romero et al. (RO_BW, RO_BR, RO_ID)
Brand authenticity (RO_BW) and brand reputation (RO_BR) are antecedents of attitude and the trust extension within TPB. RO_ID (donation intention) is the shared outcome with TPB's intention construct — the Romero model's "donation intention" is the same conceptual terminus as TPB's "intention," providing a direct point of model convergence.

## TPB (Ajzen)
The reviewed literature is foundationally organized around TPB. The meta-analytic benchmarks from White et al. (2023) provide the effect-size reference for BEBA's own model fit expectations.

## IBM (Fishbein & Yzer, 2003)
IBM adds knowledge, salience, habits, and environmental constraints to the TPB architecture. These constructs correspond directly to BEBA Behavioural Layer entries (knowledge, salience, constraints, habit) that sit alongside attitude, subjective norms, PBC, and intention in the construct ledger. IBM thus provides the theoretical grounding for the BEBA constructs that go beyond core TPB.

---

# Implications for Model Competition

The reviewed literature establishes that moral norm consistently outperforms subjective norm — raising the question of whether BEBA should operationalize "subjective norms" as a composite (including moral norm) or disaggregate them. The evidence favors disaggregation: moral norm captures self-directed ethical obligation; subjective norm captures other-directed social pressure. Both are real mechanisms but operate differently across contexts and donor types.

Trust's role is competitive with and partially overlapping with brand trust (BO_TR) already in BEBA's Brand Equity Layer. Care must be taken not to double-count trust effects: if BO_TR fully mediates the trust → attitude path, adding a separate "organizational trust" variable in the Behavioural Layer would be redundant. The structural placement of trust (Layer 3 institutional trust vs. Layer 4 brand trust vs. Layer 5 behavioral antecedent) requires clear theoretical disambiguation in the BEBA model.

---

# Open Research Questions

1. Can nonprofit brand equity (particularly brand trust and credibility) close or reduce the intention–behavior gap by providing behavioral implementation anchors (e.g., brand cues as reminders at the point of action)?
2. Does the relative dominance of PBC vs. attitude in donation prediction shift when donors are giving to brands they are highly familiar with vs. unfamiliar organizations?
3. How does moral norm interact with brand authenticity (RO_BW) in Austrian charitable giving — do donors give because it feels personally right, or because the organization is perceived as genuinely aligned with their values?
4. In an Austrian cultural context, which norm component (social pressure, moral obligation, or both) is the dominant motivational force, and what role does brand equity play in normative activation?
5. Is the intention–behavior gap systematically larger for first-time than for repeat donors — and if so, does brand commitment (BO_CO) moderate this gap through habitual activation?

---

# Suggested Ontology Entries

The following constructs warrant formal ontology candidate entries (see Step 3 output):
- Attitude (toward charitable donating)
- Subjective Norm
- Moral Norm / Personal Norm
- Perceived Behavioral Control (PBC)
- Donation Intention
- Past Donation Behavior (as PBC/habit proxy)
- Self-Identity (as a donor)
- Trust in Charitable Organization (as distinct from brand trust at Layer 4)

---

# Suggested Dissertation Use

1. **Theoretical anchoring:** Use TPB as the primary motivational backbone for BEBA's Behavioural Layer; cite White et al. (2023) meta-analysis for effect-size benchmarks and model scope.
2. **Extended model justification:** Justify inclusion of moral norm (R² gain to 52%) and trust (Lee & Kim, 2023) as theoretically motivated extensions with empirical support; connect moral norm to BEBA's epistemic/identity constructs.
3. **IBM complement:** Use IBM (Fishbein & Yzer, 2003) to justify knowledge, salience, and constraints constructs in BEBA's Behavioural Layer beyond the core TPB triad.
4. **Hypothesis generation:** Derive structural hypotheses for each TPB path (attitude → intention, subjective norm → intention, PBC → intention, intention → behavior); include moral norm as a fourth antecedent with separate hypothesis.
5. **Boundary condition framing:** Use Austrian cultural specificity as a dissertation-relevant scope condition; acknowledge that Austrian nonprofit giving may display Western TPB patterns but requires local validation.
6. **Model competition framing:** Contrast TPB's subjective norm with moral norm; use this tension to motivate the dissertation's empirical test of which norm type dominates in brand-mediated charitable giving.

---

# Confidence Assessment

| Dimension | Level | Justification |
|-----------|-------|---------------|
| Conceptual clarity | **High** | TPB constructs are well-defined, stable, and operationalisable; canonical definitions are consistent across studies |
| Empirical maturity | **High** | Meta-analytic evidence (White et al., 2023); replicated across 50+ studies, multiple donation types, and multiple cultures |
| Relevance for BEBA | **High** | TPB is the explicit foundational theory for BEBA's Behavioural Layer; its constructs are already in the BEBA Construct Ledger as "planned"; this review activates them |
