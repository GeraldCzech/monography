# SKU: Nonprofit Brand Latent Dimensions and Donation Behaviour

**Source evidence base:** Brief literature review (16 studies, 2005–2025). Findings are proportionally weighted to this evidence base. Where source evidence is thin, this is explicitly noted.

---

## Topic

How the latent (perceptual/evaluative) dimensions of nonprofit brand equity — brand image, brand personality, brand awareness/salience/familiarity, brand trust, and brand commitment — drive charitable giving outcomes, including donation intention, giving propensity, and bequest intention.

---

## Scientific Relevance

Charitable giving is a complex behaviour that resists purely rational economic explanations. Donors often lack reliable information about nonprofit performance (a credence-goods problem), making perceptual signals — how a charity looks, feels, and is remembered — central to their decisions. Brand equity constructs are the main theoretical vocabulary for capturing these perceptual signals at the organisational level. Understanding which brand dimensions drive giving, and through what mechanisms, is directly relevant to both nonprofit management practice and to building causal models of donor behaviour. For BEBA specifically, this body of work identifies which brand equity variables belong in the model and how they connect to behavioural and resource-layer outcomes.

---

## Historical Development

The application of brand equity theory to nonprofits follows commercial branding scholarship with a lag of roughly a decade. Venable et al. (2005) provided the first validated nonprofit brand personality scale, establishing that donors ascribe human personality traits to charities and that these traits predict giving likelihood. Michel and Rieunier (2012, 2014) subsequently demonstrated that nonprofit brand image — structured around functional and affective facets — accounts for meaningful variance in both monetary and volunteer giving intentions. The 2010s saw the research field expand along two axes: (1) antecedents of nonprofit brand equity (e.g., heritage, social media, website quality) and (2) the mediating mechanisms that connect brand perceptions to behaviour (trust, attitude, satisfaction). The 2020s literature consolidates trust as the central mediating construct and introduces newer brand dimensions (heritage, congruence, strength) as antecedents. Romero et al. (2023) represent the most recent attempt to build an integrated donor-based brand equity model for NGOs, positioning commitment as a key equity driver.

---

## Major Theoretical Schools

**1. Brand equity as perceptual asset:** Drawing on Keller's customer-based brand equity framework (adapted for nonprofits), this school treats awareness, image, personality, and associations as layered assets that cumulatively generate donor value. Faircloth's model (referenced as FC in BEBA) is the primary structural expression of this for nonprofits.

**2. Trust-mediated exchange:** This school treats trust as the critical intervening mechanism between brand perceptions and giving behaviour. Brand image and personality build credibility, but it is trust — confidence in the nonprofit's reliability and benevolence — that converts perception into commitment and action. Consistent with signalling theory: brand equity signals trustworthiness to information-constrained donors.

**3. Identification and self-congruence:** A third strand argues that giving is partly identity-expressive. Donors choose charities whose brand personalities match their own self-concept (actual or ideal). Crawford and Jackson (2025) and Millán et al. (2023) bring this perspective to bear, the latter linking brand identification to donation intention alongside past behaviour.

**4. Behavioural intention models (TPB-adjacent):** Several studies embed brand constructs within intention models, treating brand attitude, subjective norms, and perceived behavioural control as the proximal drivers of intention, with brand equity constructs as more distal antecedents shaping those proximal determinants.

---

## Canonical Definitions

| Construct | Canonical Definition for BEBA Use |
|---|---|
| Brand image | The set of functional and affective associations a donor holds about a nonprofit brand, structured around perceived usefulness, efficiency, affect, and dynamism (Michel & Rieunier, 2012) |
| Brand personality | The set of human personality traits perceived to characterise a nonprofit brand; includes integrity, nurturance, sophistication, and ruggedness dimensions validated for nonprofits (Venable et al., 2005) |
| Brand salience | The degree to which a nonprofit brand is prominent and distinctive in the donor's memory at the point of giving decisions (Gregory et al., 2019; Ngo et al., 2021) |
| Brand familiarity | The extent of a donor's prior exposure to and recognition of a nonprofit (Katz, 2018) |
| Brand trust | A donor's confident belief in a nonprofit brand's reliability, integrity, and benevolence; both a brand equity dimension and a mediator of giving behaviour (Bilgin & Kethüda, 2022; Kutlu & Özcan, 2024; Millán et al., 2023) |
| Brand commitment | An emotional and attitudinal bond — analogous to loyalty — between donor and nonprofit brand; associated with long-term support (Romero et al., 2023; D'souza et al., 2021) |

---

## Core Mechanisms

### Antecedents → Mediators → Moderators → Outcomes

**Antecedents of brand equity dimensions:**
- Digital touchpoints (website quality, social media marketing) → brand image and brand trust (Huang & Ku, 2016; Bilgin & Kethüda, 2022)
- Brand heritage (organisational longevity and continuity) → brand trust (Kutlu & Özcan, 2024)
- Brand experience (direct/indirect contact with the charity) → brand personality perception → donor satisfaction (Ali et al., 2022)
- Religious participation → brand image relevance in faith-based contexts (D'souza et al., 2021)

**Direct effects on giving:**
- Brand image → donation intention (money and time): multiple replications, moderate-to-large effect
- Brand personality (congruence) → self-reported giving: Crawford & Jackson, 2025
- Brand salience → brand choice intention: mainly via brand attitude
- Brand familiarity → propensity to donate: Katz, 2018
- Brand trust → donation intention: consistent direct effect across multiple studies
- Brand commitment → donor-based brand equity → support intentions: Romero et al., 2023

**Mediators on the giving pathway:**
- Brand attitude mediates salience → brand choice intention
- Brand trust mediates: (a) social media → donation intention; (b) brand heritage → donation intention
- Brand personality mediates brand experience → re-donation intention
- Donor satisfaction mediates brand experience → re-donation intention (alongside/after personality)
- Perceived transparency mediates brand strength → donation/bequest intentions

**Moderators:**
- Monetary incentives weaken the brand personality → donation intention path (Shehu et al., 2016), especially when trust is already high
- Donor stage (new vs. established): salience and familiarity more critical for new donors; trust and commitment more operative for established donors
- Organisational size: brand personality effects more influential in smaller charities
- Context (faith-based vs. secular): religious participation amplifies image–commitment–motivation relationships

**Outcomes:**
- Donation intention (money, time)
- Propensity/likelihood to donate
- Brand choice intention
- Re-donation intention
- Bequest intention
- Volunteer retention (partially overlapping with donor commitment)

---

## Empirical Evidence

The empirical base is coherent but modest in methodological diversity. Survey and SEM studies dominate, with Shehu et al. (2016) providing the only experimental manipulation in this set. Key quantified findings are: brand image explains up to 31% of monetary giving intention variance and 24% of time-giving intention variance (Michel & Rieunier, 2012). Beyond these figures, the reviewed literature does not report standardised effect sizes or meta-analytic summaries, limiting precise effect size estimation.

Trust and image are the best-evidenced constructs with consistent effects across independent research groups, contexts, and outcome measures. Brand personality effects are well-documented but carry documented boundary conditions (incentive presence, organisational size, congruence operationalisation). Salience/familiarity evidence is thinner and partially contradictory (Katz, 2018). Commitment is theorised as central to donor-based brand equity (Romero et al., 2023) but its direct causal path to actual giving behaviour is not yet cleanly established in this review's evidence base.

**Important note:** The source is a brief AI-assisted literature review from Consensus. It is unlikely to be exhaustive. The evidence base here should be treated as indicative rather than comprehensive.

---

## Theoretical Tensions

**1. Trust as brand equity dimension vs. trust as mediator:** Some studies position trust as a component of brand equity (alongside image and personality); others treat it as a mediating mechanism through which image and personality operate on giving. The dual role is theoretically coherent (trust is both built by brand perceptions and does causal work on behaviour) but risks double-counting in structural models. BEBA should specify whether trust appears in the Brand Equity Layer, the Behavioural Layer, or both, and with what causal role.

**2. Familiarity vs. trustworthiness (Katz, 2018):** The Katz finding — that familiarity, but not trustworthiness, predicted donation propensity — runs against the dominant trust literature. This may reflect measurement artefacts (unaided recall design, different trustworthiness scale) or a genuine context-specificity (awareness-stage donors driven by recognition rather than evaluative trust). It introduces uncertainty about the relative importance of familiarity versus trust at different donor journey stages.

**3. Brand personality as direct driver vs. indirect driver:** Venable et al. (2005) demonstrate direct personality → giving effects; Ali et al. (2022) find the path runs through satisfaction; Crawford & Jackson (2025) route it through congruence. These are not necessarily contradictory, but the mediating structure is unsettled. Personality's effect on giving may be fully mediated in experienced-donor segments while retaining a direct path for new donors.

**4. Commitment as equity component vs. equity output:** Romero et al. (2023) model commitment as an antecedent driver of donor-based brand equity. In Boenigk & Becker (BO_CO), commitment is a distinct equity dimension alongside trust. In D'souza et al. (2021), commitment appears as an outcome of brand image. Clarifying whether commitment precedes, constitutes, or follows from brand equity is essential for BEBA model specification.

---

## Boundary Conditions

1. Effects of brand image and personality on giving may be stronger in low-information environments where donors cannot evaluate nonprofit performance objectively (credence-goods logic).
2. Brand salience and familiarity effects are likely most pronounced at the awareness and consideration stages of the donor journey; at loyalty stages, image, trust, and commitment dominate.
3. Monetary incentives disrupt the brand personality pathway; in incentive-rich fundraising campaigns (matching gifts, lotteries), intrinsic brand signals may be crowded out.
4. Faith-based and secular nonprofits may operate different brand–commitment–motivation structures; religious identification may amplify or replace brand equity effects.
5. Digital channel context (website, social media) modulates the image–trust pathway; offline-only or service-delivery contexts may show different brand formation processes.
6. Organisational scale constrains which brand dimensions are feasible investments; small charities may rely more on personality distinctiveness; large charities on image credibility and trust.

---

## Criticism

1. **Intention–behaviour gap:** Nearly all studies use self-reported donation intention as the outcome. The gap between stated intention and actual donation behaviour is well-documented in the broader giving literature. Evidence that brand equity dimensions predict actual giving (amounts, frequency) is not established in this review.
2. **Cross-sectional designs:** All findings are susceptible to common method bias and cannot establish temporal ordering or causality robustly.
3. **Western, non-Austrian samples:** The evidence base does not include Austrian-specific data. Cultural variation in trust propensity, charity density, and religious giving patterns may limit direct transfer.
4. **Self-report bias:** Charitable giving is subject to social desirability effects; self-reported giving and congruence perceptions may be inflated.
5. **Brand equity scale fragmentation:** Different studies use different scales and items for nominally similar constructs (e.g., trust), reducing cross-study comparability.
6. **Limited coverage of negative brand equity:** All reviewed findings concern positive brand dimensions. No study addresses how brand damage, scandal, or negative image affects giving, which is directly policy-relevant for nonprofit managers.

---

## Connections to BEBA

| BEBA Layer | Relevant Constructs and Links |
|---|---|
| **Epistemic Layer** | Brand salience and familiarity reduce search/cognitive costs; donors rely on heuristics anchored in brand recognition under bounded rationality |
| **Information Economics Layer** | Brand image, personality, and trust serve as credence-good signals; they substitute for performance information donors cannot directly verify; brand heritage signals organisational longevity (reducing adverse selection risk) |
| **Institutional Layer** | Brand trust and brand reputation (partially overlapping with image) constitute the institutional legitimacy felt by donors toward a nonprofit; perceived transparency (Wymer & Čačija) is an accountability signal |
| **Brand Equity Layer** | Core home of all reviewed constructs: FC_BI (brand image), FC_BP (brand personality), FC_BF (familiarity), BO_TR (brand trust), BO_CO (brand commitment), RO_BR (reputation as image facet), RO_BW (authenticity — not directly evidenced in this review but conceptually adjacent to image/personality congruence) |
| **Behavioural Layer** | Brand attitude mediates salience → choice; attitude is the proximal behavioural predictor. Brand identification (Millán et al.) sits at the intersection of brand equity and behavioural layers. Intention is the primary outcome variable across studies |
| **Resource Layer** | Donation intention is consistently the outcome but maps imperfectly to Resource Layer participation, frequency, or amount; the intention–behaviour gap is a standing challenge |

**Causal chain implied by synthesised evidence:**

Digital/offline touchpoints → Brand image + Brand personality → [mediated by] Brand trust + Brand attitude → Donation intention → (assumed) Donation behaviour

With moderating roles for: donor stage, incentive presence, organisational size, channel context, faith involvement.

---

## Connections to Existing Models

**Faircloth (FC):**
- FC_BI (brand image) is the best-evidenced BEBA construct in this review. Michel & Rieunier's (2012) four-factor image model (usefulness, efficiency, affect, dynamism) is the operationally richest nonprofit image scale found here, providing a potential FC_BI operationalisation.
- FC_BP (brand personality) is supported by Venable et al. (2005) scale (integrity, nurturance, sophistication, ruggedness) and by Stebbins & Hartman (2013), Crawford & Jackson (2025). The personality → giving path is established.
- FC_BF (familiarity) receives single-study support (Katz, 2018) with a complicating null finding for trustworthiness in the same study.

**Boenigk & Becker (BO):**
- BO_TR (brand trust) is strongly supported as both a direct driver of donation intention and a mediating mechanism. Trust is the most consistently evidenced construct across the entire review.
- BO_CO (brand commitment) receives support from Romero et al. (2023) and D'souza et al. (2021) but its direct causal path to giving behaviour is less cleanly established than trust.

**Romero et al. (RO):**
- RO_BR (reputation) is partially covered by brand image studies but reputation as a distinct construct is not cleanly separated from image in this review's evidence base.
- RO_BW (brand authenticity) is not directly evidenced in this review. The Crawford & Jackson (2025) self-congruence construct is conceptually adjacent (genuine fit between donor values and brand personality) but not a direct test of authenticity.
- RO_ID (donation intention) is the dominant outcome variable across all studies, confirming its centrality in BEBA's causal chain.

**TPB:**
- Brand attitude (Gregory et al., Ngo et al.) aligns with TPB's attitude component.
- Brand identification (Millán et al.) is conceptually adjacent to subjective norms (social identity aspects).
- The evidence base does not test PBC or subjective norms in relation to brand equity constructs; this connection remains a gap.

**IBM (Integrated Behavioural Model):**
- Millán et al. (2023) invoke past behaviour alongside brand identification and trust, consistent with IBM's inclusion of behavioural experience as a direct predictor. This is the closest connection to IBM in the reviewed evidence, but it is not a full IBM test.

---

## Implications for Model Competition

The reviewed evidence most strongly supports the **FC + BO trust-commitment pathway** within BEBA: brand image and personality (FC constructs) build trust (BO_TR), which drives donation intention, with commitment (BO_CO) as a reinforcing attitudinal bond for sustained giving. The RO authenticity construct lacks direct evidence in this review and remains theoretically specified rather than empirically grounded from this source. The TPB/IBM behavioural intention architecture remains the preferred proximal framework, with brand equity constructs operating as more distal antecedents shaping attitude and intention.

No reviewed study pits alternative brand equity models against each other in a competitive test. Model competition within BEBA therefore remains an open design question not resolvable from this evidence alone.

---

## Open Research Questions

1. Does brand image predict actual donation amounts and frequency, or only intention?
2. What is the relative predictive weight of brand image vs. brand trust vs. brand personality when all three are entered simultaneously?
3. Does the familiarity–trustworthiness dissociation (Katz, 2018) replicate in European or Austrian contexts?
4. How does brand commitment develop over time among recurring donors, and what role do brand equity dimensions play in maintaining it?
5. Is brand congruence (Crawford & Jackson, 2025) a moderator, mediator, or direct predictor of giving — and does it operate independently of brand personality?
6. How does negative brand equity (scandal, accountability failure) erode donation intention, and which dimensions are most vulnerable?
7. Can brand equity constructs explain variation in donation amount (not just intention) when income and habit are controlled?
8. How does the brand equity → giving pathway differ across Austrian nonprofit subsectors (health, social services, international aid)?

---

## Suggested Ontology Entries

Based on evidence strength and BEBA relevance, the following constructs warrant formal ontology entries:

1. **Brand image** (FC_BI) — High priority; best-evidenced construct; multi-faceted operationalisation available
2. **Brand personality** (FC_BP) — High priority; validated scale; multiple replications
3. **Brand trust** (BO_TR) — High priority; strongest mediator evidence; dual role as equity dimension and behavioural mechanism
4. **Brand familiarity** (FC_BF) — Medium priority; single direct study but consistent with broader awareness literature
5. **Brand salience** — Medium priority; limited replication but conceptually distinct from familiarity; relevant for new-donor targeting
6. **Brand commitment** (BO_CO) — Medium priority; theorised as key equity driver; direct giving path underspecified
7. **Brand congruence** (new entry candidate) — Low-Medium priority; emerging construct; single recent study; adjacent to authenticity

The following are not yet ready for ontology formalisation from this evidence base:
- Brand heritage (single study; antecedent rather than core equity dimension)
- Brand strength (composite construct; definitional clarity needed)
- Perceived transparency (mediator within brand strength study; may belong under accountability in Institutional Layer)

---

## Suggested Dissertation Use

1. **Chapter 2 (Literature Review):** Provides the empirical grounding for BEBA's Brand Equity Layer (Layer 4). The synthesised antecedents–mediators–outcomes chain provides the scaffolding for the theoretical model.
2. **Chapter 3 (Model Specification):** The trust-as-mediator evidence supports positioning BO_TR as a bridge between the Brand Equity Layer and the Behavioural Layer in the BEBA causal model.
3. **Chapter 4 (Hypotheses):** All five core brand equity constructs (image, personality, familiarity, trust, commitment) have sufficient evidence to justify confirmatory hypotheses in an Austrian sample.
4. **Chapter 5 (Measurement):** Michel & Rieunier (2012) for FC_BI; Venable et al. (2005) for FC_BP; standard trust scales (reinforced by Bilgin & Kethüda, Kutlu & Özcan) for BO_TR.
5. **Limitation discussion:** The intention–behaviour gap, cross-sectional design constraint, and absence of Austrian data are ready-made limitations to acknowledge.

---

## Confidence Assessment

| Dimension | Level | Rationale |
|---|---|---|
| Conceptual clarity | **High** | Core constructs are well-defined with established measurement traditions; some boundary ambiguity around trust (equity dimension vs. mediator) and commitment (antecedent vs. component of equity) |
| Empirical maturity | **Medium** | Consistent directional findings across independent studies; but dominated by intention outcomes, cross-sectional designs, non-Austrian samples, and limited effect-size reporting |
| Relevance for BEBA | **High** | All reviewed constructs map directly onto BEBA's Brand Equity Layer; mediation pathways inform causal model structure; gaps (Austrian context, actual behaviour, competitive model tests) define the dissertation's contribution space |
