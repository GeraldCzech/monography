# Synthesized Knowledge Unit (SKU): Network/Process Models of Brand Equity vs. Static Indices

---

# Topic

The explanatory superiority of network- and process-based models of brand equity over traditional static index frameworks, and the structural and methodological implications of this superiority for causal modelling of brand-driven consumer behaviour.

---

# Scientific Relevance

Brand equity is among the most studied constructs in marketing science, yet its measurement and causal architecture remain contested. The debate between static indices (which summarise equity as a weighted combination of dimensions) and network/process models (which treat equity as an emergent property of sequential and relational causal chains) is not merely methodological — it is ontological. What brand equity *is* determines what it causes, how it is built, and under what conditions it can be broken down and repaired. This question has direct implications for the BEBA framework, which models nonprofit brand equity as a multi-layered causal system culminating in donation behaviour: if brand equity dimensions operate sequentially and relationally rather than additively, the BEBA causal chain must specify the ordering and interdependence of its constructs (awareness → image → trust → commitment → donation intention), not simply their simultaneous presence.

---

# Historical Development

The field passed through several identifiable phases:

**Phase 1 — Dimensional decomposition (1990s):** Aaker (1996) and Keller (1993) independently established the dominant paradigm of consumer-based brand equity (CBBE) as a multi-dimensional construct. Aaker's framework is additive; Keller's is explicitly network-based (associative memory), though it was largely operationalised as an index in applied research. Krishnan (1996) extended the associative memory framework by examining the characteristics (favourability, strength, uniqueness) of individual associations. These works established awareness and associations as the foundational architecture of equity.

**Phase 2 — Measurement proliferation and critique (2000s–early 2010s):** The proliferation of CBBE measures led to fragmentation. Burmann et al. (2009) introduced an identity-based model integrating internal (brand identity) and external (brand image) poles. Buil et al. (2013) demonstrated systematic links from brand equity dimensions to consumer responses (loyalty, willingness to pay) using SEM. Chaudhuri (2002) showed that brand reputation moderates the advertising–equity link, complicating simple additive models. Gutiérrez et al. (2023) and Tasci (2020) later documented that by this period, no single model had achieved comprehensive empirical validation.

**Phase 3 — Process/sequential modelling and cross-cultural validation (2016–2019):** Chatzipanagiotou et al. (2016, 2019) constituted the decisive intervention in the debate. Their three-block sequential model (building → understanding → relationship) was empirically tested across cultures using both SEM and fsQCA, demonstrating that the sequential, configurational structure outperformed linear/additive alternatives in predicting willingness to pay, recommendation intent, and repurchase. This period also saw Zollo et al. (2020) showing mediation paths through consumer experience and benefits in social media contexts.

**Phase 4 — Computational, neurobiological, and expanded contexts (2022–2025):** Xu et al. (2022) and Pournarakis (2017) applied machine learning to brand association networks at scale. Watanuki and Akama (2022) provided neurobiological evidence for multidimensional, dynamic processing. Chatzipanagiotou et al. (2025) extended the process model internally to employee-based equity. Petersen (2025) introduced digital media co-occurrence network analysis. Guhl (2024) contributed the first household panel approach to time-varying equity, addressing the longitudinal gap.

---

# Major Theoretical Schools

**1. Additive/Static Index School (Aaker tradition):** Equity is the sum of weighted dimensional scores. Measurement is compositional. Financial valuation is the primary goal. Limitation: treats dimensions as causally parallel, cannot diagnose sequential breakdowns, misses interaction effects.

**2. Associative Memory/Network School (Keller tradition):** Equity resides in the structure of brand knowledge in consumer memory. Associations vary in strength, valence, and uniqueness. The consumer's knowledge network determines responses. This is a structural (topological) view of equity, not additive. Limitation: originally operationalised as surveys, not as true network measurements; computational extensions (Xu et al., 2022; Pournarakis, 2017) are correcting this.

**3. Sequential Process School (Chatzipanagiotou tradition):** Equity is an emergent outcome of a three-stage sequential process. Configurational causation (fsQCA) replaces additive causation. The model is diagnostic: each stage can be evaluated independently. This school represents the strongest direct challenge to static indices in the reviewed literature.

**4. Identity-Based School (Burmann et al.):** Equity is the congruence between internally managed brand identity and externally perceived brand image. This model requires dual data sources (internal and external) and is particularly relevant to organisational branding contexts, including nonprofits that manage both mission-identity and public-facing image.

**5. Computational/Neurocognitive School (emerging):** Equity is measurable through processing behaviour (neural activations, digital association patterns) rather than through survey responses alone. This school validates the multidimensionality and dynamic nature of equity processing but lacks cross-cultural validation and standardised application.

---

# Canonical Definitions

**Brand Equity (preferred synthesis):** The differential value accruing to a brand by virtue of its accumulated knowledge, relational history, and associative network in consumer memory, expressed through causal pathways from awareness through associations, trust, and relationship quality to behavioural outcomes. Equity is not a static score but an emergent property of a sequential, configurable causal process (Keller, 1993; Chatzipanagiotou et al., 2016).

**Static Index:** A measurement approach summarising brand equity as an additive or linear composite of dimensional scores (Aaker, 1996; Tasci, 2020).

**Network/Associative Model:** A model treating brand equity as a structured memory network in which nodes (associations) are linked by relationships of varying strength, valence, and uniqueness (Keller, 1993; Krishnan, 1996).

**Process/Sequential Model:** A model treating brand equity as the emergent outcome of a temporally and causally ordered sequence of consumer–brand interactions (Chatzipanagiotou et al., 2016).

---

# Core Mechanisms

## Antecedents
- Marketing communications and advertising (Chaudhuri, 2002; Zollo et al., 2020)
- Social media brand engagement and consumer benefits (Zollo et al., 2020)
- Brand identity management by the organisation (Burmann et al., 2009; Chatzipanagiotou et al., 2025)
- Familiarity and exposure (Keller, 1993; Krishnan, 1996)
- Sponsorship and co-branding (Cornwell et al., 2022)

## Mediators (in process/network models)
- Brand awareness → brand associations (Keller, 1993)
- Brand understanding (second block, mediating building → relationship) (Chatzipanagiotou et al., 2016)
- Brand trust (Anselmsson et al., 2017)
- Brand experience (Zollo et al., 2020)
- Brand attitudes (Troiville, 2024)

## Moderators
- Culture / individual cultural values (Han et al., 2021; Chatzipanagiotou et al., 2019)
- Relationship quality (Chatzipanagiotou et al., 2019)
- Brand reputation (Chaudhuri, 2002)
- Industry / product/service category (Gutiérrez et al., 2023)
- Internal brand asset management (Chatzipanagiotou et al., 2025)

## Outcomes
- Willingness to pay a premium (Chatzipanagiotou et al., 2016, 2019)
- Recommendation intent / word-of-mouth (Troiville, 2024; Chatzipanagiotou et al., 2016)
- Repurchase / loyalty (Buil et al., 2013; Troiville, 2024)
- Brand equity scores (as latent construct outcome of the process)

---

# Empirical Evidence

The evidence base for the superiority of process/network models over static indices is strong (three high-quality findings), with the core result replicated across cultural contexts:

1. Chatzipanagiotou et al. (2016) — SEM-based validation of the three-block process model in a European context, outperforming linear alternatives on three outcome criteria.
2. Chatzipanagiotou et al. (2019) — fsQCA-based cross-cultural extension confirming configurational superiority and revealing cultural moderation of the process.
3. Han et al. (2021) — Demonstrated cultural value moderation of cognitive–social brand equity processes in global hospitality, consistent with the process model's predictions.

Supporting evidence for network model validity:
- French & Smith (2013): scale development for brand association strength.
- Xu et al. (2022): ML-based mapping of brand knowledge networks from consumer text data.
- Watanuki & Akama (2022): neuroimaging meta-analysis confirming multidimensional, dynamic neural processing of brand equity.

Longitudinal evidence is limited to Guhl (2024), which demonstrates temporal variation in brand equity using household panel data — validating the dynamic (non-static) conceptualisation but stopping short of testing process model predictions over time.

---

# Theoretical Tensions

**Tension 1 — Additive vs. configurational causation.** Static index models assume that brand equity is the sum of its parts; process/network models assume that the configuration and sequence of parts matters more than the sum. These are incompatible ontological assumptions. The empirical evidence reviewed here favours configurational models, but most applied research (especially in management/accounting) still uses additive indices for reasons of parsimony and comparability. This tension has not been fully resolved.

**Tension 2 — Consumer-based vs. identity-based equity.** CBBE models (Keller, Aaker, Chatzipanagiotou) measure equity from the consumer side. Identity-based models (Burmann et al., 2009) measure it as congruence between internal and external brand perceptions. These models require different data and yield different diagnostics. For nonprofits (relevant to BEBA), both sides are critical: organisational mission (identity) and donor perception (image) must be jointly managed.

**Tension 3 — Survey-based vs. computational measurement.** Traditional CBBE measurement uses consumer surveys, which are retrospective and subject to demand effects. Computational approaches (ML, neuroimaging) access consumer cognition more directly but are not yet standardised or cross-culturally validated. The theoretical models are largely compatible; the measurement traditions are not yet integrated.

**Tension 4 — Cross-sectional vs. longitudinal evidence.** Process models are inherently temporal (stages unfold over time), but most empirical evidence is cross-sectional. The process model's claim to superiority rests on a structural (sequential) rather than a temporal (longitudinal) argument, which is a logical gap. Guhl (2024) is the only study in this review that addresses longitudinal dynamics directly.

---

# Boundary Conditions

1. The advantage of process/network models over static indices is most clearly established in retail and service contexts; it is underexplored in digital-only, nonprofit, and emerging market contexts.
2. Process models require sufficient sample sizes and analytic resources (SEM, fsQCA) that may not be feasible in small-N charitable sector research.
3. Cultural moderators (Han et al., 2021; Chatzipanagiotou et al., 2019) imply that the optimal configuration of process stages varies by cultural context — Austrian donor samples (relevant to BEBA) have not been specifically tested.
4. Computational network models cannot yet be used as direct substitutes for survey-based CBBE measures without validation studies.
5. Financial metric integration is underdeveloped; static indices retain an advantage when the outcome of interest is financial valuation rather than behavioural prediction.

---

# Criticism

1. **Parsimony concerns:** Process models are more complex to specify, estimate, and interpret than static indices. Their superiority in predictive accuracy comes at a cost in tractability and replicability (Gutiérrez et al., 2023; Keller & Brexendorf, 2019).

2. **Lack of standardization:** No agreed-upon set of items, blocks, or stages for process models exists across the literature. This prevents meta-analysis and cross-study comparison (Tasci, 2020; Gutiérrez et al., 2023).

3. **Cross-sectional validity claims:** The claim that process models are "process" models is challenged by the fact that virtually all empirical tests are cross-sectional — they test sequential structural paths, not genuine temporal processes (Guhl, 2024 partially addresses this).

4. **Domain specificity of reviewed evidence:** Nearly all high-confidence empirical evidence comes from commercial goods/services sectors. Application to nonprofits, charitable giving, and credence goods (which are the contexts relevant to BEBA) is entirely absent from the reviewed literature.

5. **Publication bias:** The review literature (Gutiérrez et al., 2023; Paschina, 2025) notes that many models in the field lack comprehensive empirical validation, suggesting that the positive findings may partly reflect publication selection.

---

# Connections to BEBA

## Layer Placement

| BEBA Layer | Relevant Concepts from This Review |
|---|---|
| **Brand Equity Layer (Layer 4)** | All reviewed brand equity constructs (awareness, associations, trust, commitment, image, reputation) are core occupants of this layer. The Chatzipanagiotou process model (building → understanding → relationship) maps onto the sequential deepening of brand equity within this layer. |
| **Epistemic Layer (Layer 1)** | Associative memory models (Keller, 1993; Krishnan, 1996) and the heuristic use of brand associations under uncertainty are directly relevant; donors may rely on brand knowledge networks as cognitive shortcuts under bounded rationality. |
| **Information Economics Layer (Layer 2)** | Brand equity as a signal: strong brand associations reduce information asymmetry between nonprofit and donor. Reputation as a moderator (Chaudhuri, 2002) parallels the role of credibility signals in credence good markets. |
| **Institutional Layer (Layer 3)** | Identity-based brand equity (Burmann et al., 2009) intersects with institutional legitimacy; organisational brand management maps onto accountability and trust maintenance. |
| **Behavioural Layer (Layer 5)** | Mediating role of brand attitudes and word-of-mouth (Troiville, 2024) connects to attitude formation and social norm effects in the TPB/IBM framework. |
| **Resource Layer (Layer 6)** | Willingness to pay, recommendation intent, and repurchase in commercial contexts are structurally analogous to donation participation, word-of-mouth fundraising, and repeat giving in the charitable sector. |

## Causal Links to BEBA Constructs

- The Chatzipanagiotou three-block process maps onto BEBA as: **brand building** (FC_BF familiarity + FC_BI brand image) → **brand understanding** (FC_BP brand personality + BO_TR brand trust) → **brand relationship** (BO_CO brand commitment + RO_ID donation intention).
- Brand reputation as a moderator (Chaudhuri, 2002) directly reinforces RO_BR's placement as a moderating construct in the Romero et al. strand of BEBA.
- The mediation of brand attitudes (Troiville, 2024) toward loyalty parallels the TPB attitude-to-intention pathway in BEBA's Behavioural Layer.
- Social media equity building (Zollo et al., 2020) is relevant to digital fundraising channels and online donor engagement, which BEBA will need to address in its contextual boundary conditions.

---

# Connections to Existing Models

## Faircloth (FC)
The Faircloth model's three constructs — brand image (FC_BI), brand personality (FC_BP), and brand familiarity (FC_BF) — correspond to the associative memory view of brand equity (Keller, 1993; Krishnan, 1996). Brand familiarity is an antecedent of brand image in Faircloth; this is structurally consistent with Keller's awareness-before-associations logic. The network/process literature supports treating familiarity → image → downstream outcomes as a sequential, not additive, structure.

## Boenigk & Becker (BO)
Brand trust (BO_TR) and brand commitment (BO_CO) appear in the reviewed literature as mediating constructs in process models (Anselmsson et al., 2017; Chatzipanagiotou et al., 2016). The process model analysis supports placing trust and commitment in the middle and later stages of the sequential model, not as early antecedents. This has implications for BEBA causal ordering: trust should be positioned as downstream of familiarity and image.

## Romero et al. (RO)
Authenticity (RO_BW) is not directly covered in this review. Brand reputation (RO_BR) appears as a moderator (Chaudhuri, 2002) and as a dimension within associative/network models. Donation intention (RO_ID) is the terminal outcome; the process model supports the view that it is the product of prior sequential equity-building stages rather than the direct result of any single equity dimension.

## TPB/IBM
The mediation of brand attitudes toward behavioural outcomes (Troiville, 2024) is structurally parallel to the attitude–intention link in the Theory of Planned Behaviour. Word-of-mouth as a mediator parallels the subjective norms pathway. The process model's sequential logic is compatible with the TPB's staged approach to intention formation.

---

# Implications for Model Competition

The process model evidence challenges the BEBA architecture only if BEBA's constructs are currently operationalised as parallel/additive equity dimensions without explicit causal sequencing. Key implications:

1. **Sequencing matters:** BEBA must specify whether familiarity → image → trust → commitment is a true sequential process (each stage necessary but not sufficient for the next) or a parallel array of predictors. The Chatzipanagiotou evidence favours sequential specification.

2. **Configurational causation:** Not all donors with high awareness will develop high trust; the configuration of multiple equity conditions may matter more than any single dimension's score. This supports using interaction terms or fsQCA approaches in BEBA's empirical testing phase.

3. **Mediation architecture:** The reviewed evidence suggests that brand trust and brand attitudes should be treated as mediators between earlier equity dimensions (familiarity, image) and later behavioural outcomes (donation intention), not as parallel predictors.

4. **Reputation as moderator, not direct predictor:** Chaudhuri (2002) positions reputation as moderating the advertising-to-equity link; in BEBA, this suggests RO_BR may moderate the effectiveness of communication inputs on brand equity formation rather than operating as a direct equity dimension.

---

# Open Research Questions

1. Does the Chatzipanagiotou three-block process model replicate in nonprofit/charitable giving contexts with donor samples?
2. Is the sequential stage structure (building → understanding → relationship) empirically invariant across Austrian donors, or does cultural/individual variation produce different configurational paths?
3. Can computational network methods (social media mining, digital co-occurrence) be adapted to map nonprofit brand knowledge networks in donor populations?
4. What is the temporal sequence of brand equity development in charitable relationships — are donor–charity relationships genuinely sequential, or do simultaneous processes dominate?
5. How does shared brand equity (Cornwell et al., 2022) apply to nonprofit co-branding with corporate partners in the Austrian charitable sector?
6. Does reputation moderate brand equity formation in the nonprofit sector as it does in commercial sectors (Chaudhuri, 2002), or does the salience of reputation operate differently under credence good conditions?

---

# Suggested Ontology Entries

The following constructs from this review are candidates for the BEBA ontology:

1. **Brand Equity (Process/Sequential)** — as a distinct conceptualisation from brand equity as an additive index; occupies Brand Equity Layer (Layer 4) as a meta-construct with internal sequential structure.
2. **Brand Association Network** — the organised structure of brand knowledge in consumer memory; occupies Brand Equity Layer, positioned as the structural substrate of individual equity constructs (awareness, image, personality).
3. **Brand Building Block (Process Stage 1)** — the foundational awareness/familiarity/exposure stage in the Chatzipanagiotou process model; maps to FC_BF in Faircloth.
4. **Brand Understanding Block (Process Stage 2)** — the intermediate evaluation/image/personality stage; maps to FC_BI and FC_BP.
5. **Brand Relationship Block (Process Stage 3)** — trust, commitment, and relational depth; maps to BO_TR and BO_CO.
6. **Brand Reputation (as Moderator)** — reputation moderates the communication-to-equity pathway; may require dual placement as both an equity dimension (Layer 4) and a moderator variable.

---

# Suggested Dissertation Use

1. **Chapter 2 (Theoretical Framework):** Use the Chatzipanagiotou process model to justify the sequential, layered architecture of BEBA. The three-block model provides academic precedent for treating brand equity as a staged process rather than a parallel array.

2. **Chapter 3 (Model Development):** Use the additive vs. configurational debate to frame a methodological choice between SEM-only and hybrid SEM+fsQCA testing of BEBA. Cite Chatzipanagiotou et al. (2019) and Han et al. (2021) as cross-cultural precedents.

3. **Chapter 4 (Gaps and Contribution):** The complete absence of nonprofit/charitable sector applications in the network/process model literature constitutes a clear contribution gap for the dissertation. This review's evidence can be cited to justify extending the commercial process model logic into the nonprofit donation context.

4. **Chapter 5 (Methodology):** The fsQCA method recommended by Chatzipanagiotou et al. (2019) may be considered as a supplementary method alongside SEM for testing configurational donor pathways in BEBA.

---

# Confidence Assessment

| Dimension | Level | Justification |
|---|---|---|
| Conceptual clarity | **High** | The process/network vs. static index distinction is clearly theorised across multiple schools; canonical definitions are well established (Keller, 1993; Chatzipanagiotou et al., 2016) |
| Empirical maturity | **Medium** | Strong evidence for the process model's superiority in commercial contexts; weak longitudinal evidence; no nonprofit applications; limited standardisation |
| Relevance for BEBA | **High** | The process model provides direct structural guidance for BEBA's causal architecture; each process stage maps onto existing BEBA constructs; identified gaps are precisely the gaps BEBA addresses |
