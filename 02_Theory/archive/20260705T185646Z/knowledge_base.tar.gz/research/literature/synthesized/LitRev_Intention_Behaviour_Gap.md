# Scientific Knowledge Unit (SKU): The Intention–Behavior Gap in Charitable Giving

---

## Topic

The intention–behavior gap in charitable giving refers to the systematic discrepancy between individuals' self-reported willingness to donate and their subsequent actual donation behavior. This SKU synthesises evidence from 50 peer-reviewed studies (1999–2023) and situates the gap as a structurally critical construct for the BEBA Research Platform, given that BEBA's survey instrument measures donation intention (RO_ID) as a proxy for resource mobilization outcomes.

---

## Scientific Relevance

The intention–behavior gap has direct methodological and substantive significance for any model that measures intention as a surrogate for behavior. In charitable giving, meta-analytic evidence (White et al., 2023) demonstrates that the Theory of Planned Behavior (TPB) explains 44% of variance in donation intention but only 19% of variance in actual donation behavior—a difference that substantially exceeds the comparable ratio in other behavioral domains. Shang et al. (2019), using a sample of more than 17,000 donors from five major charities, showed that effect sizes for satisfaction, trust, and commitment are 3–8 times larger for intention than for actual giving. In the same dataset, 27% of individuals who expressed no intention to give actually donated. These figures collectively establish that intention is a biased and inflated predictor of charitable behavior, not merely an imperfect one.

For BEBA specifically, this means that any model using RO_ID (donation intention) as the primary endogenous behavioral outcome will systematically overestimate the real-world fundraising impact of upstream constructs (brand trust, brand commitment, credibility, authenticity, reputation). The scientific task is therefore not simply to acknowledge the gap but to model the conditions under which it is larger or smaller.

---

## Historical Development

The scientific study of the intention–behavior gap in prosocial behavior develops across three phases visible in the reviewed literature:

**Phase 1 — TPB application (1999–2007):** Sargeant (1999) proposed an early model of donor behavior. Smith & McSweeney (2007) tested a revised TPB in charitable giving and identified the intention–behavior discrepancy explicitly. These papers establish that intention is a real but imperfect predictor.

**Phase 2 — Extensions and moderators (2011–2018):** Multiple research teams extended TPB with additional predictors—moral norms (Linden, 2011), self-efficacy and social norms (Knowles et al., 2012), empathy and credibility (Liu et al., 2018), extended TPB with Canadian donors (Mittelman & Rojas-Méndez, 2018). Blake (2018) formulated the "knowledge-behavior gap" as a distinct variant. These efforts improved explanatory power for intention but did not substantially close the behavior prediction gap. Social norm alignment was identified as a moderating force (Gugenishvili, 2022, though the finding dates to this period's theoretical groundwork).

**Phase 3 — Quantification, meta-analysis, and mechanisms (2019–2023):** Shang et al. (2019) provided the first large-scale empirical quantification of the differential effect sizes for intention versus behavior. Sheeran & Webb (2016) formally codified the construct and identified self-regulation failure as a root mechanism. White et al. (2023) delivered the definitive meta-analysis. Nguyen et al. (2022) provided multi-country longitudinal data; Gugenishvili (2022) experimentally tested social norms; Adomavičiūtė & Urbonavičius (2023) examined emotional and moral determinants.

---

## Major Theoretical Schools

**1. Theory of Planned Behavior (TPB) tradition:** Attitude, subjective norms, and perceived behavioral control predict intention; intention predicts behavior. The gap arises because post-intentional factors (barriers, self-regulation, opportunity) are not modeled. Multiple studies in the set apply TPB to charitable giving (Smith & McSweeney, 2007; White et al., 2023; Mittelman & Rojas-Méndez, 2018; Kashif et al., 2015; Knowles et al., 2012; Linden, 2011; Fehresti et al., 2021).

**2. Self-regulation / volitional processes school:** Sheeran & Webb (2016) represent this school. The gap is attributed not to weak intentions but to failures in translating intentions into action plans. Implementation intentions (if–then plans) are the key intervention. This tradition shifts focus from intention formation to intention enactment.

**3. Barrier / constraint school:** Nguyen et al. (2022) represent this school. Perceived constraints—time, effort, money—physically prevent intenders from acting, regardless of motivational strength. The gap is partly structural, not purely motivational.

**4. Social norm influence tradition:** Gugenishvili (2022) and adjacent work (Willer et al., 2015) emphasize that the social environment moderates whether intentions translate to actions. Norms function both as antecedents of intention and as moderators of the intention–behavior pathway.

**5. Emotional / moral triggers school:** Adomavičiūtė & Urbonavičius (2023), Nilsson et al. (2016), and Liu et al. (2018) emphasize that empathy, guilt, moral foundations, and credibility perceptions can both strengthen intentions and independently drive unplanned behavior, producing non-intenders who give.

These schools are not mutually exclusive. The current evidence suggests a multi-pathway model in which motivational failures (TPB shortfall), volitional failures (self-regulation), structural failures (barriers), and enabling conditions (social norms, emotional triggers) jointly determine whether intentions materialize as behavior.

---

## Canonical Definitions

**Intention–behavior gap:** The empirically documented discrepancy between individuals' stated willingness to perform a behavior and their subsequent actual performance of that behavior; in charitable giving, specifically the failure of donation intention to reliably predict donation behavior (Nguyen et al., 2022; White et al., 2023; Sheeran & Webb, 2016).

**Inclined abstainer:** An individual who holds a behavioral intention but does not act; the primary target population for gap-closing interventions (Sheeran & Webb, 2016).

**Implementation intention (if–then plan):** A self-regulatory strategy specifying when, where, and how an intention will be enacted; reduces gap by automating the link between situational triggers and intended action (Sheeran & Webb, 2016).

**Post-intentional process:** Any psychological or situational event occurring after intention formation that determines whether the intention is enacted; the aggregate of such processes accounts for the predictive shortfall of intention models.

---

## Core Mechanisms: Antecedents → Mediators → Moderators → Outcomes

**Antecedents of intention:**
- Attitude toward charitable giving (TPB)
- Subjective norms (TPB); injunctive and descriptive components (Gugenishvili, 2022)
- Perceived behavioral control / self-efficacy (TPB; Knowles et al., 2012)
- Moral norms, moral foundations (Linden, 2011; Nilsson et al., 2016)
- Brand trust, satisfaction, commitment (Shang et al., 2019)
- Empathy, credibility perceptions (Liu et al., 2018)
- Nonprofit reputation (Kim & Han, 2020)

**Post-intentional mediators (between intention and behavior):**
- Self-regulation / implementation planning (Sheeran & Webb, 2016)
- Awareness and information exposure (Nguyen et al., 2022)
- Intrinsic motivation, empathy arousal (Nguyen et al., 2022; Adomavičiūtė & Urbonavičius, 2023)

**Moderators of the intention–behavior link:**
- Perceived constraints (time, effort, resources): weaken conversion (Nguyen et al., 2022)
- Social norm alignment (injunctive + descriptive): strengthen conversion (Gugenishvili, 2022)
- Emotional triggers (guilt, empathy): can enable unplanned giving by non-intenders (Adomavičiūtė & Urbonavičius, 2023)
- Implementation strategy availability: moderates self-regulatory failure (Sheeran & Webb, 2016)

**Outcomes:**
- Actual donation behavior (primary; distinct from intention)
- Donation frequency and amount (Resource Layer)
- Donor retention (long-term; underdeveloped in evidence base)

---

## Empirical Evidence

The empirical record is convergent and strong on the existence of the gap, moderate on its mechanisms, and weak on reliable interventions.

**Convergent, high-strength findings:**
- The gap is real and substantial in charitable giving (Nguyen et al., 2022; White et al., 2023; Shang et al., 2019; Sheeran & Webb, 2016). No included study reports zero or negligible gap.
- TPB variables explain 44% of variance in intention but only 19% in behavior (White et al., 2023).
- Key relational constructs (trust, commitment, satisfaction) have effect sizes 3–8x larger for intention than behavior (Shang et al., 2019).
- 27% of non-intenders actually donate, demonstrating bidirectionality of the mismatch (Shang et al., 2019).
- Perceived barriers are the primary proximate cause of non-follow-through among intenders (Nguyen et al., 2022).

**Moderate-strength findings:**
- Aligned social norms increase intention-to-behavior conversion (Gugenishvili, 2022; Willer et al., 2015), but replication is limited.
- Emotional triggers (empathy, guilt) can prompt unplanned giving but are inconsistent for sustained behavior (Adomavičiūtė & Urbonavičius, 2023; Nguyen et al., 2022).
- Extended TPB models (with moral norms, self-efficacy, knowledge) improve intention prediction without closing the behavior prediction gap (Smith & McSweeney, 2007; Mittelman & Rojas-Méndez, 2018; Fehresti et al., 2021).

**Weak/emerging findings:**
- Implementation intentions (if–then plans) may close part of the gap through self-regulatory channels (Sheeran & Webb, 2016; White et al., 2023), but direct tests in charitable giving are limited in the reviewed set.
- Digital fundraising context effects on the gap are underdeveloped (2 studies only).

---

## Theoretical Tensions

**Tension 1: Motivational adequacy vs. volitional failure.** TPB-derived research implicitly attributes the gap to unmeasured motivational variables (attitudes, norms not fully captured). Self-regulation research (Sheeran & Webb, 2016) argues the gap is primarily volitional: strong intenders still fail to act because they lack concrete plans. These accounts are complementary but prescribe different interventions.

**Tension 2: Attitude-based vs. spontaneous behavior.** A significant share of charitable donations appear to be unplanned (27% of non-intenders giving; Shang et al., 2019). This challenges the assumption that donation behavior is primarily attitude-driven and deliberate. Spontaneous giving triggered by emotional appeals or situational exposure may follow a different pathway entirely.

**Tension 3: Role of brand constructs (trust, commitment).** Shang et al. (2019) demonstrate that brand-related relationship constructs explain intentions well but behavior poorly. This creates a tension with the dominant paradigm in nonprofit brand equity research (which treats these constructs as behavioral drivers): they may be primarily intention-level determinants, with behavior responding more to situational and volitional factors.

**Tension 4: Moral norms vs. social norms.** Linden (2011) and Nilsson et al. (2016) emphasize moral foundations as predictors; Gugenishvili (2022) and Willer et al. (2015) emphasize social norms. The relative weight of internalized moral motivation versus social compliance in the intention-to-behavior conversion is not resolved by the evidence.

---

## Boundary Conditions

1. Evidence is primarily from Western, developed-country contexts (Australia, New Zealand, Canada, USA). Non-Western evidence (Iran, Kuwait) is limited and not systematically compared.
2. The gap may vary by charity type, cause area, donation modality (regular vs. one-off), and donation channel (offline vs. digital). Differentiation is not systematically pursued in the reviewed set.
3. Emotional trigger effects are likely context-dependent (disaster giving vs. routine giving) and may not generalize.
4. Social norm effects have not been tested in Austrian nonprofit or European charity contexts specifically relevant to BEBA.
5. Digital giving contexts are underrepresented; conversion mechanisms in online fundraising may differ.

---

## Criticism

1. **Measurement conflation:** Many studies measure behavioral intention using single-item or attitudinal scales that may capture attitude strength rather than genuine behavioral commitment. This inflates apparent intention–behavior correlations and obscures gap size.
2. **Self-report bias for behavior:** Studies relying on self-reported donation behavior (rather than administrative records) are subject to social desirability bias, which artificially inflates apparent intention-to-behavior consistency.
3. **Temporal gap variability:** The time interval between intention measurement and behavior measurement varies widely across studies, from weeks (experiments) to months (longitudinal). Gap size is sensitive to this interval but this is rarely systematically addressed.
4. **Publication bias toward gap existence:** No included study reports a negligible gap. Publication asymmetry cannot be ruled out.
5. **Intervention evidence is weak:** The reviewed literature is stronger on documenting the gap than on closing it. Prescriptive implications are therefore stronger than the implementation evidence warrants.

---

## Connections to BEBA

**Layer placement:**
The intention–behavior gap sits at the interface of BEBA's Behavioural Layer (Layer 5) and Resource Layer (Layer 6). It describes the failure mode of the pathway from Layer 5 constructs (intention, RO_ID) to Layer 6 outcomes (donation participation, frequency, amount).

**Causal relevance:**
- The gap directly challenges BEBA's implicit assumption that RO_ID (donation intention as measured in the survey) is a valid proxy for actual giving.
- Shang et al. (2019) show that trust (BO_TR) and commitment (BO_CO)—both core BEBA constructs—have systematically inflated effect sizes on intention relative to behavior. BEBA's structural model, if validated only on intention data, will overstate the real-world fundraising impact of the brand equity layer.
- The IBM constructs already present in BEBA (knowledge, salience, habit, constraints) directly address the mechanisms of the gap: constraints is the primary barrier identified by Nguyen et al. (2022); habit captures the sustained giving dimension; knowledge and salience map to the awareness/exposure pathway documented for non-intenders.

**Enactment Layer positioning:**
The reviewed literature supports the theoretical grounding of BEBA's Enactment Layer (IBM constructs). Specifically:
- Constraints (time, effort, resources) as gap-widening barriers (Nguyen et al., 2022)
- Habit as a potential gap-closing mechanism (sustained behavior independent of deliberate intention)
- Salience as a mechanism enabling non-intender spontaneous giving (Nguyen et al., 2022)
- Knowledge as a precondition for deliberate enactment of intention (Blake, 2018)

**Measurement implication for BEBA:**
BEBA's reliance on RO_ID as a behavioral outcome measure carries a systematic inflation bias. The magnitude of this bias is empirically estimable (3–8x on key constructs; Shang et al., 2019). BEBA should either (a) qualify its conclusions regarding behavioral impact by explicitly referencing the intention–behavior gap literature, or (b) incorporate moderation analyses testing whether IBM constructs (constraints, habit) reduce the gap in the Austrian context.

---

## Connections to Existing Models

**Faircloth model (FC_BI, FC_BP, FC_BF):**
Brand image (FC_BI), brand personality (FC_BP), and familiarity (FC_BF) are upstream antecedents in BEBA's brand equity layer. The intention–behavior gap literature implies that their effects on actual giving behavior are mediated through intention but subject to post-intentional attenuation. No direct test of Faircloth constructs versus actual giving behavior (as opposed to intention) is present in the reviewed set.

**Boenigk & Becker model (BO_TR, BO_CO):**
Brand trust (BO_TR) and brand commitment (BO_CO) are directly implicated by Shang et al. (2019), who show these constructs have 3–8x larger effects on intention than on behavior. This is the single most direct empirical threat to BEBA's brand equity—behavior causal chain. The implication is that trust and commitment are primarily intention-level constructs rather than behavioral drivers.

**Romero et al. model (RO_BW, RO_BR, RO_ID):**
Authenticity (RO_BW), reputation (RO_BR), and donation intention (RO_ID) are all upstream of actual behavior. The gap literature implies that RO_ID's predictive validity for real-world giving is substantially attenuated by post-intentional processes, and that RO_BW and RO_BR have even more distal and attenuated relationships to actual giving behavior.

**TPB:**
Directly tested in the gap literature. TPB accounts for 44% of variance in charitable intention but only 19% in behavior. BEBA's Behavioural Layer constructs (attitude, subjective norms, PBC) are TPB elements; the gap literature implies they are stronger predictors of RO_ID than of actual donation behavior (Layer 6).

**IBM (extends TPB):**
IBM's additional constructs—knowledge, salience, habit, constraints—are precisely the variables identified by the gap literature as the post-intentional moderators and mediators. IBM is therefore better positioned than TPB to bridge the gap. Constraints and habit are the IBM constructs with the most direct support from the reviewed gap literature.

---

## Implications for Model Competition

The reviewed evidence generates testable competing hypotheses within BEBA:

1. **H_gap1:** The effect of BO_TR and BO_CO on Layer 6 outcomes (donation behavior) is substantially smaller than their effect on RO_ID (donation intention). Expected if Shang et al. (2019) findings generalize to the Austrian context.

2. **H_gap2:** IBM constructs (constraints, habit) moderate the intention–behavior conversion in the Austrian nonprofit context, such that models including these constructs have greater predictive validity for behavioral outcomes than TPB-only models.

3. **H_gap3:** RO_ID is a biased upward proxy for donation behavior; structural models relying on RO_ID as the terminal outcome will systematically overstate causal effect sizes for upstream brand equity constructs.

These hypotheses are not currently testable within BEBA's existing survey design if donation behavior is not independently measured. However, they can be incorporated as explicit methodological qualifications and as a motivation for longitudinal or administrative data linkage in future work.

---

## Open Research Questions

1. Do Austrian donors exhibit a magnitude of intention–behavior gap comparable to documented findings in Anglophone/Western contexts? The Austrian nonprofit sector and giving culture may differ.
2. Which IBM constructs most strongly moderate the intention–behavior conversion in the Austrian context?
3. Does brand equity (as operationalised in BEBA) have differential effects on intention vs. actual behavior, and if so, by how much?
4. Can digital fundraising interventions (platforms, nudges) reliably close the gap in repeated giving contexts?
5. What is the role of habit in sustaining donation behavior beyond initial intention in the Austrian context?

---

## Suggested Ontology Entries

The following constructs from the reviewed literature are candidates for the BEBA ontology (see Step 3 for full entries):

1. **Intention–Behavior Gap** (meta-construct / measurement validity concern; Behavioural–Resource Layer interface)
2. **Inclined Abstainer** (behavioral type; Behavioural Layer)
3. **Perceived Constraints** (IBM construct / gap moderator; Enactment Layer / Behavioural Layer)
4. **Implementation Intention** (self-regulatory mechanism; Enactment Layer)
5. **Post-Intentional Process** (mechanism class; Enactment Layer)
6. **Spontaneous Giving / Unplanned Donation** (behavioral category; Resource Layer)

---

## Suggested Dissertation Use

1. **Methodological limitation acknowledgment (Chapter 3 / Methods):** BEBA measures RO_ID as a proxy for donation behavior. The intention–behavior gap literature (White et al., 2023; Shang et al., 2019; Sheeran & Webb, 2016) establishes that this is a conservative and inflated estimate of actual giving. This should be explicitly acknowledged as a measurement limitation, with quantitative bounds cited (19% vs. 44% variance explained; 3–8x effect size differential).

2. **Theoretical motivation for IBM constructs (Chapter 2 / Theory):** The IBM's extensions to TPB (knowledge, salience, constraints, habit) are justified by the gap literature as addressing documented mechanisms of post-intentional failure. This strengthens the theoretical rationale for including IBM constructs in BEBA over a pure TPB baseline.

3. **Model competition hypothesis (Chapter 4 / Analysis):** Testing whether models including IBM constructs better predict behavioral proxies (donation frequency, amount) than models relying only on TPB intention measures is a directly motivated hypothesis from this literature.

4. **Practical implications (Chapter 5 / Discussion):** Charities cannot rely on intention measures alone to forecast giving behavior; practical interventions must address constraints and support self-regulation.

---

## Confidence Assessment

| Dimension | Level | Rationale |
|---|---|---|
| Conceptual clarity | High | The intention–behavior gap is a precisely defined, well-operationalised construct with consistent definition across the reviewed literature |
| Empirical maturity | High | Large-N field data (Shang et al., 2019), systematic meta-analysis (White et al., 2023), longitudinal data (Nguyen et al., 2022) establish the existence and magnitude of the gap robustly |
| Relevance for BEBA | High | The gap directly threatens the validity of BEBA's primary outcome measure (RO_ID) and provides theoretical justification for BEBA's Enactment Layer (IBM constructs); the connection is structural, not peripheral |
