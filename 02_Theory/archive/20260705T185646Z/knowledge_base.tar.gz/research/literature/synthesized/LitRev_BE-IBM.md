# Scientific Knowledge Unit: Brand Equity and the Integrated Model of Behaviour (IBM)

Source documents: LitRev_BE-IBM.md (source) + LitRev_BE-IBM.md (evidence map)
Processed for BEBA Research Platform.

---

# Topic

Integration of customer-based brand equity (CBBE) with IBM-type behavioural frameworks (Integrated Model of Behaviour / Theory of Planned Behaviour). Specifically: the structural role of CBBE dimensions within behavioural intention models — as antecedents to attitude and perceived behavioural control, as mediators between upstream brand perceptions and downstream intentions, or as direct predictors of behavioural intention.

---

# Scientific Relevance

Brand equity and behavioural intention models have historically developed in parallel streams without systematic integration. Their convergence matters because it addresses the explanatory gap in pure TPB/IBM applications (which do not specify what drives attitude) and the action gap in pure brand equity research (which does not specify how equity translates to behaviour). For BEBA, this convergence is directly relevant: the dissertation asks how nonprofit brand equity drives charitable giving in Austria, which requires precisely the CBBE→attitude→intention pathway to be established and its moderators identified.

---

# Historical Development

The integration of brand equity with behavioural models has progressed in three phases visible in this corpus:

**Phase 1 — Separate frameworks (pre-2010):** Brand equity measurement (Aaker, Keller) and the TPB/IBM tradition (Ajzen, Fishbein) developed independently. Burmann et al. (2009) and Das et al. (2009) represent early calls for integration and for treating brand equity as a dynamic system rather than a static measurement score.

**Phase 2 — Structural integration (2016–2020):** Rodrigues & Martins (2016) formalised the perceptual/behavioural split within CBBE. Rambocas et al. (2017) and Jiang et al. (2017) built mediated–moderated SEM models connecting brand equity to behavioural intentions. Wu et al. (2020) provided the first meta-analytic synthesis of CBBE–TPB integration, establishing the canonical path structure: CBBE dimensions → attitude → loyalty → brand equity → behavioural intention.

**Phase 3 — Contextual extension and configurality (2019–2025):** Chatzipanagiotou et al. (2019) introduced the three-block configural model. Zheng et al. (2025) replicated and extended the integrated CBBE–TPB framework in a new domain (EV adoption). Wu et al. (2025) extended the integration to social cognitive theory. Increasing attention to digital platforms (Algharabat et al., 2020; Hsu, 2023), sustainability contexts (Ha, 2021; Singh et al., 2023), and employee-based brand equity (Boukis & Christodoulides, 2018; Chatzipanagiotou et al., 2025) marks the current frontier.

---

# Major Theoretical Schools

**1. CBBE-first perspective:** Treats brand equity as the superordinate construct; TPB/IBM constructs (attitude, PBC, intention) are positioned as downstream outcomes or pathways through which brand equity exerts its effects. Representative: Wu et al. (2020) meta-analytic framework, Zheng et al. (2025).

**2. Behaviour-first perspective:** Treats the IBM/TPB intention model as the primary explanatory structure; brand equity components (awareness, image, trust) are positioned as antecedents that enrich the model by specifying what drives attitude and PBC. These two perspectives are often conflated in the literature but produce different causal diagrams with different intervention implications.

**3. Configural/relational perspective:** Rejects linear causal hierarchies in favour of block models where brand building, brand understanding, and brand relationship contribute jointly and non-linearly to brand equity; cultural context moderates block weights. Representative: Chatzipanagiotou et al. (2019).

**4. Identity-based brand equity:** Burmann et al. (2009) — brand equity derives from the match between brand identity (internal) and brand image (external); this perspective is not pursued further in the reviewed empirical corpus but is structurally compatible with nonprofit brand authenticity research.

---

# Canonical Definitions

**Customer-based brand equity (CBBE):** A multi-dimensional latent construct comprising brand awareness, associations/image, perceived quality, loyalty, trust, and sometimes personality or reputation. Distinguished into perceptual inputs (awareness, image) and behavioural outputs (loyalty, willingness to pay) (Rodrigues & Martins, 2016; Wu et al., 2020; Chatzipanagiotou et al., 2019).

**Configural CBBE:** A three-block model — (1) brand building: imagery/functionality; (2) brand understanding: awareness/reputation/associations/self-connection; (3) brand relationship: relevance/intimacy/trust — each contributing to overall brand equity, with block weights moderated by cultural context (Chatzipanagiotou et al., 2019).

**IBM / TPB (as operationalised in this literature):** A latent-variable model in which attitude, perceived behavioural control, and (implicitly) subjective norms predict behavioural intention. Note: In this corpus IBM is operationalised equivalently to TPB; the additional IBM constructs of Fishbein & Yzer (2003) — knowledge, salience, habit, constraints — are not empirically tested in integration with CBBE. This is a structural limitation for BEBA, which relies on the full IBM specification.

---

# Core Mechanisms

## Antecedents → Mediators → Moderators → Outcomes

**Antecedents to attitude (upstream CBBE → attitude):**
- Brand image/personality/associations (Wu et al., 2020)
- All four CBBE components independently influence attitude (Zheng et al., 2025)
- Customer engagement and experience in digital/service contexts (Algharabat et al., 2020; Satar et al., 2023)

**Antecedents to loyalty:**
- Brand awareness, trust, perceived quality, and PBC (Wu et al., 2020)

**Mediators:**
- Attitude (partial mediation: CBBE dimensions → attitude → intention; direct paths also persist)
- Satisfaction (brand equity → satisfaction → repeat purchase / WTP / WOM)
- Trust (brand equity component and mediator)
- Loyalty (intermediate outcome between lower-order CBBE dimensions and behavioural intention)
- Emotional attachment (engagement → attachment → CBBE → intention in digital/service contexts)

**Moderators:**
- Price perception (Zheng et al., 2025)
- Cultural dimensions — individualism/collectivism (Chatzipanagiotou et al., 2019)
- Customer demographics (Rambocas et al., 2017)
- Omnichannel integration quality (Yeğin & Ikram, 2022)
- Ecological consciousness (Singh et al., 2023)

**Outcomes:**
- Behavioural intention (purchase, repurchase, adoption, word-of-mouth, donation — the last is extrapolated, not tested in the corpus)
- Loyalty
- Willingness to pay
- Switching behaviour
- Word-of-mouth / recommendation

**Direction of effects:**
- Consistently positive: higher CBBE → stronger attitude → stronger behavioural intention
- No study in the corpus reports a negative or null direct effect of CBBE on intention

---

# Empirical Evidence

The corpus provides multi-level empirical support:

**Meta-analytic level (highest quality):** Wu et al. (2020) establish the canonical integrated path structure across prior studies, supporting both the CBBE → attitude link and the brand equity → intention link.

**SEM-replication level (high quality):** Zheng et al. (2025) independently replicate and extend the integrated framework in electric vehicle adoption with a large Chinese sample, finding full support for CBBE components influencing attitude and partial mediation.

**Domain-specific SEM (medium quality, context-restricted):** Rambocas et al. (2017) in banking; Martín et al. (2019) in tourism; Jiang et al. (2017) in culinary tourism; Algharabat et al. (2020) and Satar et al. (2023) in social media and service brands. These extend the framework to new domains but do not test all CBBE dimensions uniformly.

**Cross-cultural validation (high quality, but commercial only):** Chatzipanagiotou et al. (2019) provide the most rigorous cross-cultural evidence for the configural model.

**Notable absence:** No study in the corpus tests the CBBE–IBM integration in nonprofit, charitable giving, or donation contexts. All evidence is from commercial brand and consumer product/service domains.

---

# Theoretical Tensions

**Tension 1 — Antecedent vs. outcome ambiguity:** Brand equity is simultaneously positioned as an antecedent to intention (in CBBE-first models) and as an outcome of loyalty and attitude (in Wu et al., 2020's meta-analytic path model). The bidirectionality is theoretically unresolved: the two directions may reflect different time horizons (brand equity as stock built from past attitudes vs. brand equity as current driver of future intention), but no longitudinal study in the corpus tests this.

**Tension 2 — IBM vs. TPB equivalence:** The reviewed literature operationalises IBM as TPB (attitude, PBC, subjective norms → intention). The full IBM specification (Fishbein & Yzer, 2003) adds knowledge, salience, habit, and constraints as factors that can prevent or facilitate acting on intention. The corpus provides no evidence on whether CBBE dimensions also predict these additional IBM factors. For BEBA, which explicitly models all IBM factors, this is a structural gap: the CBBE → IBM integration as reviewed here covers only the TPB subset.

**Tension 3 — Full mediation vs. direct effects:** Multiple studies report partial mediation (attitude partially mediates CBBE → intention, with direct paths remaining). This implies brand equity has pathways to intention that bypass attitude, which is theoretically important but underexplored. Candidates include self-congruity, habitual choice, or stored evaluative schema — none tested in the corpus.

**Tension 4 — Linear hierarchy vs. configural blocks:** The meta-analytic Wu et al. (2020) framework is hierarchical and linear (CBBE dimensions → attitude → intention). Chatzipanagiotou et al.'s (2019) configural block model is non-linear and relational. These two architectures are not reconciled in the reviewed literature.

---

# Boundary Conditions

1. **Domain restriction to commercial brands:** All empirical evidence is from for-profit brand contexts. The applicability to nonprofit brands and charitable giving requires explicit testing. The mechanisms that make brand equity salient in consumer purchase decisions (e.g., price-quality inference, competitive differentiation) differ from those in donation decisions (altruism, social identity, moral norms).

2. **Cross-sectional design:** All primary studies are cross-sectional (confirmed by the Research Gaps Matrix). The causal direction of the CBBE → attitude → intention path cannot be established from available evidence; longitudinal or experimental designs are needed.

3. **Cultural moderation:** The magnitude (and potentially the direction) of CBBE effects on behavioural outcomes is moderated by cultural context (individualism/collectivism). Austrian cultural dimensions (moderately collectivist, high uncertainty avoidance) have not been studied in this corpus.

4. **IBM completeness:** Results apply only to the TPB subset of the IBM. Whether knowledge, salience, habit, and constraints are similarly predicted by CBBE dimensions is unknown.

5. **Positive perceptions bias:** All studies focus on positive brand perceptions. The effect of negative or mixed CBBE on intention — relevant for nonprofits with damaged reputations — is not covered.

---

# Criticism

1. **Conflation of IBM with TPB:** The labelling of the reviewed framework as "IBM" is imprecise. The additional IBM constructs are not operationalised. This reduces the contribution to BEBA's specific theoretical architecture.

2. **Domain homogeneity of corpus:** Despite 50 papers, the corpus is heavily skewed toward consumer electronics, green products, and digital contexts. Replication in nonprofit, public goods, or prosocial behaviour domains is absent, limiting transferability.

3. **Meta-analysis scope limitation:** Wu et al. (2020), the highest-quality source, is based on a limited number of prior studies and is published in a lower-tier journal (*Journal of Asian Finance, Economics and Business*), which warrants caution about the generalisability of its path coefficients.

4. **Measurement heterogeneity:** CBBE is operationalised differently across studies (different dimensions, scales, and numbers of items), making cross-study comparison unreliable. This is acknowledged in the source as a standardisation gap.

5. **Absence of negative case analysis:** No study in the corpus tests conditions under which integrating CBBE into IBM does not improve explanatory power. The claim that integration is beneficial could be publication-biased.

---

# Connections to BEBA

## Layer Placement

**Brand Equity Layer (Layer 4):** The CBBE construct and its dimensions (awareness, image, perceived quality, trust, loyalty, personality) map directly onto BEBA's Brand Equity Layer. The configural block model's three blocks — brand building (imagery/functionality), brand understanding (awareness/reputation/associations/self-connection), and brand relationship (relevance/intimacy/trust) — partially overlap with BEBA's Layer 4 constructs: FC_BI (image), FC_BF (familiarity/awareness), FC_BP (personality), BO_TR (trust), BO_CO (commitment/loyalty), RO_BR (reputation), RO_BW (authenticity).

**Behavioural Layer (Layer 5):** Attitude is a Layer 5 construct in BEBA (IBM/TPB: attitude → intention). The reviewed literature establishes that CBBE dimensions are antecedents of attitude. In BEBA's causal structure, this means Layer 4 constructs drive Layer 5 constructs — a cross-layer causal link that is empirically supported in commercial contexts.

**Resource Layer (Layer 6):** Behavioural intention in the reviewed literature corresponds to donation participation/frequency/amount in BEBA's Resource Layer. The reviewed literature does not cover charitable giving outcomes, so extrapolation is required.

## Causal Links Supported by Evidence

- **CBBE dimensions → Attitude (Layer 4 → Layer 5):** High-evidence path. Image/personality/association → attitude (Wu et al., 2020). In BEBA terms: FC_BI, FC_BP → Attitude.
- **CBBE dimensions → Loyalty (within Layer 4):** Awareness, trust, perceived quality → loyalty. In BEBA terms: FC_BF, BO_TR → BO_CO.
- **Attitude → Behavioural Intention (Layer 5 → Layer 5/6):** Standard TPB/IBM path, confirmed in integrated models. Partial mediation implies direct paths from CBBE to intention also exist.
- **Brand Equity → Behavioural Intention (Layer 4 → Layer 6, partial direct path):** The direct path from overall brand equity to intention (bypassing attitude) requires modelling in BEBA.

## Mediators within BEBA

- **Attitude** as mediator between Brand Equity Layer and Behavioural Layer (partial mediation confirmed).
- **Satisfaction** — not currently an explicit BEBA construct; could be positioned in Layer 5 as an evaluative state mediating between brand equity and donation intentions.
- **Trust (BO_TR)** functions as both a CBBE component (Layer 4) and a mediator to behaviour (Layer 5 gateway). This dual role is important for BEBA model specification.

## Moderators within BEBA

- **Cultural context:** Austria is a specific cultural setting; cultural moderation effects require attention but are partially covered by the Austrian institutional context (Layer 3 in BEBA).
- **Price perception / resource constraints:** Maps to BEBA's Layer 6 Resource Layer and the IBM constraint construct — financial resource constraints moderate the donation participation pathway in a manner analogous to price moderation in purchase contexts.
- **Knowledge and salience (IBM-specific):** Not addressed in the reviewed literature but are BEBA's IBM-specific additions to TPB. Future research should test whether CBBE dimensions (especially FC_BF awareness/familiarity) predict knowledge and salience in donation contexts.

---

# Connections to Existing Models

## Faircloth Model (FC_BI, FC_BP, FC_BF)

The reviewed literature directly supports the Faircloth model's structure. Wu et al. (2020) identify brand image/personality/association as antecedents of attitude — matching FC_BI and FC_BP as Layer 4 drivers of Layer 5 attitude. Brand familiarity/awareness (FC_BF) is positioned as an antecedent of loyalty in the meta-analytic model. The configural CBBE block "brand understanding" (awareness/reputation/associations) maps to FC_BF and FC_BI. Evidence strength for the Faircloth pathways is High within commercial contexts; medium for direct transposition to nonprofit giving.

## Boenigk & Becker Model (BO_TR, BO_CO)

Trust (BO_TR) and commitment/loyalty (BO_CO) appear as both CBBE components and mediators in the reviewed literature. Trust mediates CBBE → behaviour (Rambocas et al., 2017; Chatzipanagiotou et al., 2019); loyalty mediates lower-order CBBE → intention (Wu et al., 2020). This double role — as Layer 4 constructs and as within-layer mediators to Layer 5 — is fully consistent with Boenigk & Becker's positioning of trust and commitment as the relational core of nonprofit brand equity. The reviewed evidence strengthens the rationale for BO_TR as a key mediating construct in BEBA.

## Romero Model (RO_BW, RO_BR, RO_ID)

Authenticity (RO_BW) is not explicitly tested in the reviewed literature; it is not among the canonical CBBE dimensions in the Wu et al. (2020) or Chatzipanagiotou et al. (2019) frameworks. Reputation (RO_BR) appears in the brand understanding block (Chatzipanagiotou et al., 2019) but is not separately modelled in the meta-analysis. Donation intention (RO_ID) corresponds to the behavioural intention outcome in BEBA's Layer 5/6. The reviewed literature provides no direct evidence for the RO_BW → RO_ID or RO_BR → RO_ID pathways in charitable giving contexts. These remain extrapolations requiring direct testing.

## TPB (Attitude, Subjective Norms, PBC → Intention)

The reviewed literature is effectively a literature on CBBE × TPB integration. The TPB pathways are confirmed as the internal mechanism of IBM in all reviewed studies. CBBE dimensions augment the TPB model by specifying the antecedents of attitude. Subjective norms are the least-addressed TPB construct in the reviewed corpus — their interaction with CBBE is not modelled. PBC appears as an antecedent of loyalty (Wu et al., 2020) and as a predictor of purchase intention alongside CBBE components (Zheng et al., 2025).

## IBM (Full Fishbein & Yzer 2003 Specification)

The reviewed literature does not address the IBM-specific extensions: knowledge, salience, habit, constraints. In BEBA's architecture these are critical because:
- **Knowledge** (about the nonprofit, its mission, its impact) likely mediates or moderates the CBBE → attitude path — an informed donor may weight brand reputation more heavily.
- **Salience** may interact with FC_BF (familiarity) — familiar nonprofits become salient at decision points.
- **Habit** in donation behaviour may reduce the role of attitude and brand equity processing in repeat donors.
- **Constraints** (financial, social, temporal) may moderate the intention → donation participation path independently of brand equity levels.

None of these interactions has been tested empirically. This is a direct research gap for the BEBA dissertation.

---

# Implications for Model Competition

The reviewed evidence creates three specific implications for model competition within BEBA:

1. **CBBE → Attitude path supports FC_BI and FC_BP as upstream drivers:** If the meta-analytic finding (image/personality → attitude) holds in Austrian nonprofit contexts, then Faircloth's brand image and brand personality constructs earn their position as key Layer 4 → Layer 5 pathways. This would place FC_BI and FC_BP in direct competition with BO_TR and BO_CO for explanatory primacy — the former being more cognitive/associative, the latter more relational/affective.

2. **Trust as both component and mediator challenges clean model boundaries:** The literature suggests BO_TR (brand trust) may be endogenous to both the Faircloth block (as an associative dimension of brand image) and the Boenigk–Becker block (as an affective-relational construct). If trust is partly determined by image and partly by commitment, the BEBA models are not cleanly separable.

3. **Direct brand equity → intention path challenges pure attitude-mediation:** If the partial mediation finding replicates in nonprofit contexts, a direct path from overall brand equity (or specific dimensions like reputation/authenticity) to donation intention should be included in BEBA's structural model alongside the attitude-mediated path. This directly benefits the Romero model (RO_BR → RO_ID direct) and suggests that not all brand equity effects on giving pass through the attitude formation process.

---

# Open Research Questions

1. **Does CBBE improve the explanatory power of the full IBM (not just TPB) in nonprofit/charitable donation contexts?** Specifically: do CBBE dimensions predict knowledge, salience, and habit alongside attitude?
2. **Which CBBE dimensions are most salient for donation intention versus commercial purchase intention?** Trust and authenticity may outweigh awareness and perceived quality in prosocial decisions.
3. **Does the CBBE → attitude path operate identically for nonprofit brands as for commercial brands?** The evaluative standards differ (mission alignment vs. quality-price ratio).
4. **Is the direct brand equity → donation intention path (bypassing attitude) significant in Austrian nonprofit contexts?** This would support including a direct Layer 4 → Layer 6 path in BEBA.
5. **How do the IBM constructs of knowledge, salience, habit, and constraints interact with nonprofit CBBE?** This is the core gap between the reviewed literature and BEBA's full specification.
6. **Does longitudinal change in nonprofit brand equity predict change in donation frequency or amount?** No longitudinal evidence exists anywhere in the corpus.

---

# Suggested Ontology Entries

Based on this review, the following constructs merit formal ontology entries for BEBA:

1. **Customer-based brand equity (CBBE) — multi-dimensional structure:** Ontology entry capturing the dimensionality, the configural block model, and the standard operationalisation as a higher-order latent construct.
2. **Attitude (as CBBE outcome and TPB/IBM antecedent):** Its dual position — downstream of brand equity and upstream of intention — requires a single ontology entry that encodes both roles.
3. **Satisfaction (as potential mediator):** Not currently in BEBA; the reviewed evidence suggests it may mediate between nonprofit brand equity and donation repetition.
4. **Perceived behavioural control (PBC):** Confirmed as both an antecedent of loyalty and a predictor of intention in CBBE-integrated models; needs explicit BEBA ontology positioning.
5. **Configural brand building blocks (brand building / brand understanding / brand relationship):** May offer a useful organisational schema for grouping BEBA's Layer 4 constructs.

---

# Suggested Dissertation Use

1. **Chapter: Theoretical Framework — IBM and Brand Equity Integration.** Use Wu et al. (2020) meta-analysis as the primary evidential anchor for the CBBE → attitude → intention pathway. Cite Zheng et al. (2025) as independent replication. Position BEBA as the first application of this integrated framework to nonprofit/charitable giving in an Austrian context.

2. **Chapter: Model Specification.** Use the evidence of partial mediation (attitude does not fully mediate CBBE → intention) to justify including both mediated paths (via attitude) and direct paths (brand equity → donation intention) in BEBA's structural model.

3. **Chapter: Boundary Conditions and Generalisability.** Use the absence of nonprofit evidence in this corpus as the primary justification for original empirical data collection in Austria. Reference the cultural moderation findings (Chatzipanagiotou et al., 2019) to justify Austrian-specific contextualisation.

4. **Chapter: Gaps and Future Research.** Use the longitudinal gap and the IBM-completeness gap (knowledge, salience, habit, constraints untested) as forward-looking research agenda items.

5. **Measurement Chapter.** Use Rodrigues & Martins (2016) perceptual/behavioural CBBE split to guide scale selection for nonprofit brand equity measurement.

---

# Confidence Assessment

**Conceptual clarity — Medium**
The IBM construct is operationalised inconsistently across the corpus (usually as TPB only). The CBBE construct is multi-dimensional but lacks standardisation. The key pathway structures are conceptually clear; the construct boundaries are not. For BEBA, the limited IBM operationalisation in the reviewed literature creates conceptual ambiguity that must be resolved through explicit construct mapping.

**Empirical maturity — Medium**
The meta-analysis (Wu et al., 2020) and the Zheng et al. (2025) replication provide a reasonably mature evidence base for the core CBBE–TPB integration in commercial contexts. However, all evidence is cross-sectional, all domains are commercial, and standardisation is absent. Applying these findings to Austrian nonprofit giving requires bridging assumptions that reduce confidence.

**Relevance for BEBA — Medium-High**
The core mechanism (brand equity dimensions → attitude → intention) is directly relevant to BEBA's Layer 4 → Layer 5 → Layer 6 causal chain. The trust and commitment mediator evidence directly strengthens BO_TR and BO_CO's positioning. The absence of nonprofit/donation context evidence is a significant limitation, but the commercial evidence provides a theoretically grounded extrapolation basis. Relevance is high in principle; applicability remains to be tested empirically.
