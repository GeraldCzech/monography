# Synthesised Knowledge Unit (SKU): Fishbein & Yzer's Integrated Model of Behaviour (IBM) Applied to Charitable Donations

---

## Topic

The IBM (Fishbein & Yzer, 2003) as a framework for predicting charitable donation intention and behaviour, including its TPB/TRA antecedents and the extended models that populate the empirical literature. Central question: can the IBM's full construct set — experiential/instrumental attitudes, injunctive/descriptive norms, self-efficacy/PBC, and the direct behavioural determinants (knowledge, salience, environmental constraints, habit) — adequately account for why people donate, and how should this be incorporated into BEBA's Behavioural Layer?

---

## Scientific Relevance

The IBM represents the most comprehensive intention-based behavioural model currently available in social and health psychology. Its application to charitable giving is extensive: a 2023 meta-analysis (White et al., 2023) confirms that TPB-based constructs — the core of IBM — are robust predictors of donation intention across diverse donation modalities (money, time, blood, organ). The framework has generated a cumulative, cross-disciplinary evidence base and now serves as the de facto theoretical backbone for predicting prosocial behaviour in academic and applied contexts. For BEBA, IBM provides the most direct structural account of how motivational and normative antecedents translate into donation intention and, through several moderating pathways, into donation enactment.

---

## Historical Development

The IBM's genealogy in charitable giving research runs as follows:

1. **TRA era (Fishbein & Ajzen, 1975)**: Attitude and subjective norm as sole predictors of intention. Limited application to prosocial behaviour; early charity models (Sargeant, 1999) began borrowing attitudinal constructs from this framework.

2. **TPB era (Ajzen, 1991)**: Addition of PBC extended explanatory power; first systematic applications to blood and monetary donation (Smith & McSweeney, 2007 being a pivotal early study). The revision of TPB to include moral norm (Linden, 2011) marked a critical expansion.

3. **IBM era (Fishbein & Yzer, 2003)**: Full integration of self-efficacy alongside PBC, differentiation of norm types (injunctive vs. descriptive), decomposition of attitude into experiential and instrumental components, and explicit inclusion of habit, knowledge, salience, and environmental constraints as direct behavioural determinants beyond intention. In practice, the IBM label is rarely used in the charitable giving literature — most studies apply IBM-equivalent constructs under extended-TPB labels.

4. **Extension and integration era (2015–2025)**: A wave of studies adds trust, motivation, religiosity, cultural values, and digital platform variables. Meta-analytic synthesis (White et al., 2023) and systematic reviews (Benli & Kocaman, 2025) consolidate the evidence base. Computational, neuroscientific, and game-theoretic methods begin to complement survey-based approaches (Cohen et al., 2023; Huang et al., 2021; Rocha & Monteiro, 2023).

---

## Major Theoretical Schools

**1. Rational Choice / Expectancy-Value tradition**: Standard TPB/TRA — donation as a reasoned action based on attitude and norm. Represented by Smith & McSweeney (2007), Veludo-De-Oliveira et al. (2016).

**2. Moral obligation extension**: Adds personal moral norm as a predictor of intention distinct from social norms, drawing on Norm Activation Theory (NAT). Represented by Linden (2011), Kim & Han (2020). Challenges the sufficiency of social norms and aligns with Self-Determination Theory's intrinsic motivation dimension.

**3. Habit/automaticity tradition**: Emphasises past behaviour and habit as direct determinants of future behaviour, reducing the mediating role of intention for habitual donors. Represented by Mittelman & Rojas-Méndez (2018), Smith & McSweeney (2007).

**4. Trust-based tradition**: Treats institutional trust (toward the charitable organisation or digital platform) as an antecedent of attitude and intention. Represented by Alhidari et al. (2018), Lee & Kim (2023), Li et al. (2022). Converges with Information Economics perspectives (credence good uncertainty resolved via trust signals).

**5. Cultural/religious tradition**: Situates donating within cultural or religious norm systems (Zakat, Sadaqah, altruism norms) that operate partly outside the standard injunctive/descriptive norm structure. Represented by Chetioui et al. (2022), Anggraeni & Kuklienė (2024).

**6. Dual-process / message processing tradition**: Draws on the Elaboration Likelihood Model (ELM) to explain how message involvement moderates attitude formation and donation intention. Represented by Van Steenburg & Spears (2021). Partially bridges with IBM's experiential vs. instrumental attitude distinction.

---

## Canonical Definitions

**Intention to donate**: The expressed motivational state to perform a donation act in the near future; the most proximate cognitive determinant of actual donation behaviour within IBM/TPB.

**Attitude (experiential / instrumental)**: An overall evaluation of performing the donation behaviour. Experiential: how does it feel to donate (affective)? Instrumental: what are the consequences of donating (cognitive)? The IBM explicitly decomposes these; most reviewed studies operationalise a unidimensional or bidimensional attitude.

**Perceived norm (injunctive / descriptive)**: Injunctive: what do important others think I should do? Descriptive: what do important others actually do? Most reviewed studies operationalise subjective norm as primarily injunctive; descriptive norms appear in some extensions.

**Moral norm**: A personal sense of obligation to perform the behaviour, irrespective of social pressure. Consistently the strongest or joint-strongest predictor of charitable intention where included.

**PBC / self-efficacy**: Perceived ability and control over performing the donation. PBC is the TPB construct; self-efficacy is the IBM-specific self-regulation component. In most charitable giving studies these are treated as interchangeable or collapsed.

**Past behaviour / habit**: Prior donation history as a proxy for habitual behavioural tendencies. IBM explicitly includes habit as a direct behavioural determinant; reviewed studies operationalise this mainly as frequency of past donations.

**Trust (multidimensional)**: Encompassing cognitive trust (ability/competence of the organisation), affective trust (benevolence), and in digital contexts, technology trust. Influences attitude and intention as an antecedent, not a core IBM construct but a robust extension.

**Environmental constraints**: Structural barriers (income, access, time) that inhibit the translation of intention into behaviour. IBM's explicit construct; empirically confirmed most clearly in non-Western, low-income contexts (Musamuxamedov et al., 2025).

**Knowledge and salience**: IBM-specific direct behavioural determinants — knowing how to donate and the behaviour being sufficiently top-of-mind. Minimally operationalised in the reviewed corpus as labelled IBM constructs, though platform trust and campaign salience in crowdfunding contexts are functionally equivalent.

**Intention-action gap**: The persistent and empirically documented discrepancy between stated donation intention and actual donation behaviour (Nguyen et al., 2022). Not a construct within IBM per se, but the key practical failure mode of intention-based models.

---

## Core Mechanisms (Antecedents → Mediators → Moderators → Outcomes)

```
ANTECEDENTS
  Experiential attitude toward donating
  Instrumental attitude toward donating
  Injunctive norm (subjective norm)
  Descriptive norm
  Moral norm [extension]
  Self-efficacy / PBC
  Trust in organisation [extension]
  Trust in platform [extension — digital context]
  Religiosity / cultural values [extension — non-Western contexts]
  Income / material capacity [extension — environmental constraints]
  Past behaviour / habit

        ↓ (all antecedents → )

MEDIATOR 1: Donation intention
  (primary and most powerful mediator)

        ↓

MODERATORS on intention → behaviour path
  Environmental constraints (income, access, structural barriers)
  Habit strength (high habit = direct behaviour, bypasses intention)
  Knowledge and salience (whether the person knows how to act and behaviour is cued)
  Platform context (digital environments introduce friction/facilitation)
  Cultural/religious context (moderates norm and attitude salience)
  CEO / organisational reputation (moderates trust-to-intention link)

        ↓

OUTCOMES
  Donation participation (binary)
  Donation frequency
  Donation amount
  Donation modality (money, time, blood, goods)
  Donor retention / recurrence
```

Additional mediation noted in the literature:
- Attitude mediates trust → intention (Lee & Kim, 2023)
- Perceived credibility mediates empathy → intention in crowdfunding (Liu et al., 2018)

---

## Empirical Evidence

**Strongest and most replicated findings:**
- IBM/TPB attitude, norm, and PBC predict donation intention across all donation types (White et al., 2023 meta-analysis). Effect sizes are moderate to large for attitude and PBC; norm effects are smaller and more variable.
- Moral norm typically outperforms social norm as a predictor of charitable intention when included (Linden, 2011 — up to 70% variance explained; Kim & Han, 2020).
- Past behaviour / habit strengthens prediction of both intention and actual behaviour (Mittelman & Rojas-Méndez, 2018; Smith & McSweeney, 2007; Veludo-De-Oliveira et al., 2016).
- Intention explains moderate but not complete variance in actual behaviour — the intention-action gap is empirically real and persistent.
- IBM applied in full form: Talie et al. (2020) — 51% variance in intention, 37% in actual blood donation behaviour.

**Moderate-strength findings:**
- Multidimensional trust (cognitive, affective, platform) enhances attitude and intention (Alhidari et al., 2018; Lee & Kim, 2023; Li et al., 2022).
- Religiosity / Islamic norm structures are significant predictors in relevant populations (Chetioui et al., 2022; Anggraeni & Kuklienė, 2024).
- ELM message processing (involvement × preexisting beliefs) shapes charitable intention (Van Steenburg & Spears, 2021).

**Weaker or context-limited findings:**
- Standard IBM/TPB predictors underperform in non-Western, low-income, or high-institutional-barrier contexts (Musamuxamedov et al., 2025 — single study, PLS-SEM, Uzbekistan).
- Interventions to close the intention-action gap: not sufficiently covered in the reviewed literature.

---

## Theoretical Tensions

**1. Moral norm vs. social norm**: The IBM's injunctive norm construct does not fully capture the personal moral obligation dimension that reliably predicts charitable giving. Moral norm extensions (drawing on NAT) are empirically powerful but theoretically external to IBM. This creates construct boundary ambiguity.

**2. Habit vs. deliberate intention**: IBM positions habit as a direct determinant of behaviour alongside intention; in contexts of habitual donors, intention may be redundant. However, most studies treat intention as primary, and habit as additive rather than competing.

**3. Trust as antecedent vs. as attitude component**: Trust in the charitable organisation is operationalised variously as an antecedent to attitude, as a component of attitude (credibility dimension), or as an independent predictor of intention. This maps onto BEBA's Brand Equity Layer (brand trust construct) and creates overlap between the Behavioural and Institutional layers.

**4. PBC vs. self-efficacy**: IBM differentiates these; most charitable giving studies collapse them. The distinction matters for intervention design (targeting capability vs. control beliefs).

**5. Intention-action gap mechanism**: The gap is documented but its mechanism is underspecified in the reviewed literature. Environmental constraints, habit, and knowledge/salience (IBM's direct behavioural determinants) are candidate mechanisms but rarely tested as a bundle.

---

## Boundary Conditions

1. Model predictive validity is highest when structural barriers to giving are low (Western, affluent, educated samples).
2. For habitual donors, past behaviour dominates; attitude-based models add limited marginal value.
3. In collectivist / religious cultures, norm structures operate differently from Western injunctive/descriptive norm operationalisations.
4. Digital fundraising introduces technology trust and platform credibility as necessary constructs; original IBM was developed for offline behaviour.
5. Crisis or emergency donation contexts (pandemic, disaster) may activate different motivational pathways (empathy, descriptive norms from visible peer behaviour) that are underrepresented in steady-state IBM applications.

---

## Criticism

1. **The IBM/TPB is primarily an intention predictor, not a behaviour predictor**: Predictive power for actual behaviour is systematically lower than for intention; the model was not designed to capture implementation intentions or behavioural execution processes.
2. **Over-reliance on self-report cross-sectional surveys**: The dominant methodology introduces common method bias and cannot establish causality; longitudinal and experimental evidence is sparse.
3. **The IBM label is rarely used as such**: Most studies apply IBM constructs under TPB/extended-TPB labels, preventing cumulation under the IBM rubric and making systematic review difficult.
4. **Construct operationalisation heterogeneity**: Attitude, norm, and PBC are operationalised inconsistently across studies, limiting comparability. Trust especially suffers from conceptual proliferation (cognitive/affective/platform/competence dimensions).
5. **Cultural non-transferability**: Western normative psychology underpins the model; in societies where income constraints, institutional distrust, or non-individualistic norm systems dominate, the model's predictive architecture may not transfer.
6. **Neglect of emotional and identity-based processes**: The IBM is primarily cognitive-expectancy-based; emotional antecedents (empathy, guilt, gratitude) and donor identity processes are external additions rather than core model features.

---

## Connections to BEBA (Layer Placement, Causal Links)

**Primary layer**: BEBA Behavioural Layer (Layer 5). The IBM's core constructs — attitude, subjective/moral norms, PBC/self-efficacy, past behaviour/habit, knowledge, salience — map directly onto the Behavioural Layer constructs listed in the BEBA framework.

**Secondary layer**: BEBA Epistemic Layer (Layer 1). IBM's direct behavioural determinants — knowledge and salience — reflect bounded rationality mechanisms. A donor who lacks knowledge of how to donate, or for whom donation is not salient, will fail to enact intention regardless of motivational readiness; this is a bounded rationality failure, not a motivational failure.

**Tertiary layer**: BEBA Institutional Layer (Layer 3). Trust — whether in the charitable organisation or digital platform — enters the IBM as an antecedent to attitude and intention. This creates a causal bridge from the Institutional Layer (trust, legitimacy) through the Behavioural Layer (attitude, intention) to the Resource Layer (donation enactment).

**Resource Layer (Layer 6)**: IBM's environmental constraints construct maps directly onto BEBA's Resource Layer determinants. The intention-action gap is partly explained by resource constraints (income, time, access) that the IBM acknowledges but the reviewed literature underoperationalises.

**Brand Equity Layer (Layer 4) interface**: Trust in the charitable organisation (Alhidari et al., 2018; Lee & Kim, 2023) — a Behavioural Layer antecedent in IBM terms — is simultaneously a Brand Equity Layer outcome (brand trust, BO_TR in Boenigk & Becker). This cross-layer causal pathway is central to BEBA's theoretical architecture.

**Specific BEBA construct mappings**:
- Attitude (IBM) ↔ BEBA Behavioural Layer: attitude
- Subjective norm / injunctive norm (IBM) ↔ BEBA Behavioural Layer: subjective norms
- Descriptive norm (IBM) ↔ BEBA Behavioural Layer: subjective norms (descriptive subtype — currently implicit)
- Moral norm (IBM extension) ↔ BEBA Behavioural Layer: subjective norms (personal norm — may require separate construct)
- PBC / self-efficacy (IBM) ↔ BEBA Behavioural Layer: PBC
- Habit (IBM) ↔ BEBA Behavioural Layer: habit
- Knowledge (IBM) ↔ BEBA Behavioural Layer: knowledge
- Salience (IBM) ↔ BEBA Behavioural Layer: salience
- Environmental constraints (IBM) ↔ BEBA Behavioural Layer: constraints / Resource Layer
- Intention (IBM) ↔ BEBA Behavioural Layer: intention
- Actual behaviour (IBM outcome) ↔ BEBA Resource Layer: donation participation, frequency, amount

---

## Connections to Existing Models (Faircloth, Boenigk & Becker, Romero, TPB, IBM)

**IBM vs. TPB**: IBM is a superset of TPB. TPB covers attitude, subjective norm, PBC, and intention. IBM adds: (a) decomposition of norm into injunctive/descriptive, (b) decomposition of attitude into experiential/instrumental, (c) self-efficacy alongside PBC, (d) direct behavioural determinants (knowledge, salience, environmental constraints, habit). Most reviewed studies operate at the TPB level; the IBM's additional constructs are rarely fully operationalised.

**IBM Behavioural Layer ↔ Faircloth model (FC_BI, FC_BP, FC_BF)**: Faircloth's brand image and brand personality constructs influence how donors evaluate a charitable organisation, which feeds into attitude (IBM). Brand familiarity (FC_BF) increases salience (IBM direct determinant) and may reduce knowledge barriers. The Faircloth constructs are thus upstream antecedents to IBM's attitude and salience.

**IBM Behavioural Layer ↔ Boenigk & Becker (BO_TR, BO_CO)**: Brand trust (BO_TR) is the Brand Equity Layer analogue of trust-in-organisation as an IBM antecedent. Brand commitment (BO_CO) maps onto habit and past behaviour in the IBM (habitual giving = committed giving). The BO model provides the brand-equity-specific operationalisation of constructs that IBM treats as generic attitudinal/behavioural phenomena.

**IBM Behavioural Layer ↔ Romero et al. (RO_BW, RO_BR, RO_ID)**: Romero's brand authenticity (RO_BW) and brand reputation (RO_BR) are upstream inputs to IBM's attitude and trust-antecedents. Donation intention (RO_ID) is directly the IBM's intention construct. The Romero model is partially an IBM instance with brand-specific antecedents.

**IBM ↔ ELM (Van Steenburg & Spears, 2021)**: ELM message processing (central vs. peripheral route) shapes the formation and strength of attitudes (IBM). High-involvement processing produces stronger, more durable attitudes that more reliably predict intention. This provides a mechanism for how communication strategy (advertising content, message framing) enters the IBM.

---

## Implications for Model Competition

The IBM does not compete with BEBA's brand equity models (Faircloth, Boenigk & Becker, Romero) — it operates at a different analytical level. The brand equity models explain why donors form favourable evaluations of a nonprofit (Layers 2–4); the IBM explains how those evaluations, combined with normative and control beliefs, produce intention and behaviour (Layers 5–6). The critical integration question for BEBA is: **which brand equity constructs enter the IBM via attitude, which enter via norm, and which enter via trust/PBC pathways?**

Model competition exists between:
- TPB (standard) vs. extended TPB with moral norm — evidence favours the extended version for charitable giving
- Extended TPB vs. full IBM with all direct determinants — insufficient evidence in the reviewed literature to adjudicate fully; habit/past behaviour integration provides clear additive value
- IBM vs. culturally adapted models — in non-Western contexts, institutional and material variables may need to partially replace or supplement standard IBM predictors

---

## Open Research Questions

1. How do digital fundraising platforms alter the weighting of IBM constructs (attitude, norm, PBC) relative to platform-specific constructs (technology trust, convenience, visibility)?
2. What interventions reliably close the donation intention-action gap — and which IBM direct behavioural determinants (knowledge, salience, constraints, habit) are the most promising targets?
3. How do brand equity constructs (brand trust, brand commitment, brand authenticity) differentially feed into IBM's attitude, norm, and PBC pathways? (Direct relevance to BEBA integration.)
4. Does IBM's moral norm extension apply uniformly across religious/secular Austrian donation contexts, or does it require cultural calibration?
5. How does repeated donation experience (habit formation) interact with brand equity (commitment, loyalty) in sustaining long-term donor relationships?
6. Do the IBM's experiential and instrumental attitude dimensions respond differently to nonprofit brand communication — and if so, how should BEBA's communication recommendations differentiate between them?

---

## Suggested Ontology Entries

The following constructs merit formal ontology entries in the BEBA construct ledger:

1. **Donation Intention** (IBM core; mediator; primary outcome of Behavioural Layer)
2. **Attitude toward Donating** (IBM core; decomposed into experiential and instrumental subtypes)
3. **Subjective Norm / Injunctive Norm** (IBM core)
4. **Descriptive Norm** (IBM; currently implicit in BEBA — may be subsumed or separated)
5. **Moral Norm / Personal Norm** (IBM extension; consistently strong predictor; distinct from social norms)
6. **Perceived Behavioural Control (PBC)** (IBM/TPB core)
7. **Self-Efficacy for Donating** (IBM; distinct from PBC in full IBM formulation)
8. **Habit / Past Behaviour** (IBM direct determinant; also proxied by brand commitment)
9. **Knowledge of How to Donate** (IBM direct determinant; linked to Epistemic Layer)
10. **Salience of Donation Opportunity** (IBM direct determinant; linked to brand familiarity and Epistemic Layer)
11. **Environmental Constraints** (IBM direct determinant; linked to Resource Layer)
12. **Intention-Action Gap** (cross-framework phenomenon; critical for BEBA's enactment layer)

---

## Suggested Dissertation Use

- **Chapter: Behavioural Layer Theoretical Foundation**: Use IBM as the primary theoretical framework for BEBA's Behavioural Layer. Justify the preference for IBM over standard TPB by citing the inclusion of direct behavioural determinants (habit, knowledge, salience, environmental constraints) which address the intention-action gap.
- **Chapter: Model Integration**: Present the cross-layer causal architecture linking Brand Equity Layer outputs (brand trust, brand commitment, brand authenticity) to IBM antecedents (attitude, PBC, moral norm, habit). Cite Alhidari et al. (2018) and Lee & Kim (2023) for trust pathways; Mittelman & Rojas-Méndez (2018) for habit/past behaviour.
- **Measurement section**: Note that moral norm must be measured as a separate construct from social/injunctive norm (Linden, 2011; Kim & Han, 2020) and that past behaviour / habit requires at minimum two to three items capturing donation frequency and automaticity.
- **Boundary conditions discussion**: Address Austrian cultural context — a Western, relatively affluent context where standard IBM predictors should apply, though religious norm structures are weaker than in Islamic-norm studies. Note that digital platform trust is increasingly relevant as online giving grows in Austria.
- **Limitations**: Acknowledge that IBM's direct behavioural determinants (knowledge, salience, constraints) are rarely operationalised in the charitable giving literature and that their inclusion in BEBA represents a theoretical extension of current practice.

---

## Confidence Assessment

| Dimension | Rating | Justification |
|---|---|---|
| Conceptual clarity of IBM | High | Well-defined theoretical framework with clear construct distinctions (Fishbein & Yzer, 2003); ambiguity arises mainly from the label not being used consistently in the literature |
| Empirical maturity | High | Extensive evidence base, meta-analytic support (White et al., 2023), replicated across donation types and cultures; limits in non-Western contexts and for direct behavioural determinants |
| Relevance for BEBA | High | IBM maps directly onto BEBA's Behavioural Layer; its direct behavioural determinants address the intention-action gap that BEBA must explain; integration with brand equity models is theoretically coherent |
